class WaterIntake {
  final DateTime timestamp;
  final double glassesCount;

  WaterIntake({
    required this.timestamp,
    required this.glassesCount,
  });

  Map<String, dynamic> toMap() {
    return {
      'timestamp': timestamp.millisecondsSinceEpoch,
      'glassesCount': glassesCount,
    };
  }

  factory WaterIntake.fromMap(Map<String, dynamic> map) {
    try {
      final timestamp = map['timestamp'] is int 
        ? DateTime.fromMillisecondsSinceEpoch(map['timestamp'])
        : DateTime.now();
      
      final glasses = map['glassesCount'];
      final glassesCount = glasses is double ? glasses : (glasses is int ? glasses.toDouble() : 1.0);
      
      return WaterIntake(
        timestamp: timestamp,
        glassesCount: glassesCount.clamp(0.0, 100.0), // Reasonable bounds
      );
    } catch (e) {
      // Fallback for corrupted data
      return WaterIntake(
        timestamp: DateTime.now(),
        glassesCount: 1.0,
      );
    }
  }
}

class DailyProgress {
  final DateTime date;
  final double totalGlasses;
  final int dailyGoal;
  final List<WaterIntake> intakes;

  DailyProgress({
    required this.date,
    required this.totalGlasses,
    required this.dailyGoal,
    required this.intakes,
  });

  double get progressPercentage {
    if (dailyGoal <= 0) return 0.0;
    final percentage = totalGlasses / dailyGoal;
    if (percentage.isNaN || percentage.isInfinite) return 0.0;
    return percentage.clamp(0.0, 2.0); // Allow up to 200% for overachievement
  }

  int get hydrationLevel {
    final percentage = progressPercentage;
    if (percentage.isNaN || percentage.isInfinite) return 0;
    if (percentage >= 1.0) return 5; // Excellent
    if (percentage >= 0.8) return 4; // Good
    if (percentage >= 0.6) return 3; // Okay
    if (percentage >= 0.4) return 2; // Poor
    if (percentage >= 0.2) return 1; // Bad
    return 0; // Terrible
  }
}