CREATE OR REPLACE FUNCTION insert_user_to_auth(
    email text,
    password text
) RETURNS UUID AS $$
DECLARE
  user_id uuid;
  encrypted_pw text;
BEGIN
  user_id := gen_random_uuid();
  encrypted_pw := crypt(password, gen_salt('bf'));
  
  INSERT INTO auth.users
    (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, recovery_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, created_at, updated_at, confirmation_token, email_change, email_change_token_new, recovery_token)
  VALUES
    (gen_random_uuid(), user_id, 'authenticated', 'authenticated', email, encrypted_pw, '2023-05-03 19:41:43.585805+00', '2023-04-22 13:10:03.275387+00', '2023-04-22 13:10:31.458239+00', '{"provider":"email","providers":["email"]}', '{}', '2023-05-03 19:41:43.580424+00', '2023-05-03 19:41:43.585948+00', '', '', '', '');
  
  INSERT INTO auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at)
  VALUES
    (gen_random_uuid(), user_id, format('{"sub":"%s","email":"%s"}', user_id::text, email)::jsonb, 'email', '2023-05-03 19:41:43.582456+00', '2023-05-03 19:41:43.582497+00', '2023-05-03 19:41:43.582497+00');
  
  RETURN user_id;
END;
$$ LANGUAGE plpgsql;


SELECT insert_user_to_auth('device1@example.com', 'password123');
SELECT insert_user_to_auth('device2@example.com', 'password123');
SELECT insert_user_to_auth('device3@example.com', 'password123');

INSERT INTO notification_tokens (device_id, is_active)
SELECT 'device_xyz_123', true
UNION ALL
SELECT 'device_abc_456', true
UNION ALL
SELECT 'device_def_789', false;

INSERT INTO notification_schedules (device_id, interval_minutes, active, start_hour, end_hour)
SELECT 'device_xyz_123', 90, true, 7, 21
UNION ALL
SELECT 'device_abc_456', 45, true, 9, 23
UNION ALL
SELECT 'device_def_789', 120, false, 6, 20;

INSERT INTO notifications (device_id, title, body, sent_at, delivered, delivered_at, notification_type)
SELECT 'device_xyz_123', 'Drink, Idiot!', 'Time to hydrate!', now() - INTERVAL '30 minutes', true, now() - INTERVAL '25 minutes', 'water_reminder'
UNION ALL
SELECT 'device_xyz_123', 'Drink, Idiot!', 'Another reminder!', now() - INTERVAL '1 hour', true, now() - INTERVAL '55 minutes', 'water_reminder'
UNION ALL
SELECT 'device_abc_456', 'Drink, Idiot!', 'Stay hydrated!', now() - INTERVAL '15 minutes', false, NULL, 'water_reminder'
UNION ALL
SELECT 'device_def_789', 'Drink, Idiot!', 'You forgot to drink!', now() - INTERVAL '2 hours', true, now() - INTERVAL '1 hour 50 minutes', 'water_reminder';

INSERT INTO water_intakes (device_id, glasses_count, intake_time, daily_goal)
SELECT 'device_xyz_123', 1.5, now() - INTERVAL '2 hours', 8
UNION ALL
SELECT 'device_xyz_123', 2.0, now() - INTERVAL '1 hour', 8
UNION ALL
SELECT 'device_abc_456', 1.0, now() - INTERVAL '30 minutes', 10
UNION ALL
SELECT 'device_abc_456', 0.5, now() - INTERVAL '10 minutes', 10
UNION ALL
SELECT 'device_def_789', 2.5, now() - INTERVAL '3 hours', 6;