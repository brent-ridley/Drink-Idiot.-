-- Row Level Security Policies for Drink, Idiot app
-- Note: This assumes anonymous access for device-based functionality

-- Enable RLS on all tables
ALTER TABLE notification_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE notification_schedules ENABLE ROW LEVEL SECURITY;
ALTER TABLE water_intakes ENABLE ROW LEVEL SECURITY;

-- Notification tokens policies - allow all operations for anonymous/authenticated users
-- Since this is device-based without user authentication, we'll allow broad access
-- In production, you might want to restrict by device_id or add API key authentication

DROP POLICY IF EXISTS "Allow all operations on notification_tokens" ON notification_tokens;
CREATE POLICY "Allow all operations on notification_tokens"
ON notification_tokens
FOR ALL
USING (true)
WITH CHECK (true);

-- Notifications policies - allow all operations
-- This allows the app to create notifications and mark them as delivered

DROP POLICY IF EXISTS "Allow all operations on notifications" ON notifications;
CREATE POLICY "Allow all operations on notifications"
ON notifications
FOR ALL
USING (true)
WITH CHECK (true);

-- Notification schedules policies - allow all operations

DROP POLICY IF EXISTS "Allow all operations on notification_schedules" ON notification_schedules;
CREATE POLICY "Allow all operations on notification_schedules"
ON notification_schedules
FOR ALL
USING (true)
WITH CHECK (true);

-- Water intakes policies - allow all operations for analytics

DROP POLICY IF EXISTS "Allow all operations on water_intakes" ON water_intakes;
CREATE POLICY "Allow all operations on water_intakes"
ON water_intakes
FOR ALL
USING (true)
WITH CHECK (true);

-- Note: In a production environment, you might want to:
-- 1. Add device-specific policies that filter by device_id
-- 2. Implement API key authentication
-- 3. Add rate limiting policies
-- 4. Restrict certain operations to server-side only
-- 
-- Example of more restrictive policy (commented out):
-- CREATE POLICY "Device specific access to notifications"
-- ON notifications
-- FOR ALL
-- USING (device_id = current_setting('app.device_id', true))
-- WITH CHECK (device_id = current_setting('app.device_id', true));