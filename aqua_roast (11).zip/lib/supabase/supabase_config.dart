import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter/foundation.dart';

class SupabaseConfig {
  static const String supabaseUrl = 'https://dfezwkjrirrhkjvnfntt.supabase.co';
  static const String supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRmZXp3a2pyaXJyaGtqdm5mbnR0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTc2MTMxMTcsImV4cCI6MjA3MzE4OTExN30.l1bZyblXPMXpKcntw5VgkK214cP--qYJPyOYKJ1yNQY';
  
  static late SupabaseClient _client;
  static bool _initialized = false;

  static Future<void> initialize() async {
    if (_initialized) return;
    
    try {
      // Check if Supabase is already initialized
      if (Supabase.instance.client != null) {
        _client = Supabase.instance.client;
        _initialized = true;
        debugPrint('Supabase was already initialized');
        return;
      }
      
      await Supabase.initialize(
        url: supabaseUrl,
        anonKey: supabaseAnonKey,
      );
      
      _client = Supabase.instance.client;
      _initialized = true;
      debugPrint('Supabase initialized successfully');
    } catch (e) {
      debugPrint('Error initializing Supabase: $e');
      // Don't throw, just log the error and mark as not initialized
      _initialized = false;
    }
  }

  static SupabaseClient? get client {
    if (!_initialized) {
      debugPrint('Warning: Supabase not initialized. Call SupabaseConfig.initialize() first.');
      return null;
    }
    return _client;
  }

  static bool get isInitialized => _initialized;
}

class SupabaseService {
  static SupabaseClient? get _client => SupabaseConfig.client;

  // CRUD Operations
  static Future<List<Map<String, dynamic>>> select(String table, {String? where}) async {
    try {
      if (_client == null) {
        debugPrint('Supabase client not available for select operation');
        return [];
      }
      dynamic query = _client!.from(table).select();
      if (where != null) {
        // This is a basic implementation - you'd need to parse the where clause properly
        query = query.eq('id', where);
      }
      final List<dynamic> response = await query;
      return response.cast<Map<String, dynamic>>();
    } catch (e) {
      debugPrint('Error selecting from $table: $e');
      return [];
    }
  }

  static Future<Map<String, dynamic>?> insert(String table, Map<String, dynamic> data) async {
    try {
      if (_client == null) {
        debugPrint('Supabase client not available for insert operation');
        return null;
      }
      final response = await _client!.from(table).insert(data).select();
      return response.isNotEmpty ? response.first : null;
    } catch (e) {
      debugPrint('Error inserting into $table: $e');
      return null;
    }
  }

  static Future<Map<String, dynamic>?> update(
    String table, 
    Map<String, dynamic> data, 
    String whereColumn, 
    dynamic whereValue
  ) async {
    try {
      if (_client == null) {
        debugPrint('Supabase client not available for update operation');
        return null;
      }
      final response = await _client!
          .from(table)
          .update(data)
          .eq(whereColumn, whereValue)
          .select();
      return response.isNotEmpty ? response.first : null;
    } catch (e) {
      debugPrint('Error updating $table: $e');
      return null;
    }
  }

  static Future<void> delete(String table, String whereColumn, dynamic whereValue) async {
    try {
      if (_client == null) {
        debugPrint('Supabase client not available for delete operation');
        return;
      }
      await _client!.from(table).delete().eq(whereColumn, whereValue);
    } catch (e) {
      debugPrint('Error deleting from $table: $e');
    }
  }

  // Real-time subscriptions
  static RealtimeChannel? subscribeToTable(
    String table, 
    void Function(PostgresChangePayload) onData
  ) {
    if (_client == null) {
      debugPrint('Supabase client not available for subscription');
      return null;
    }
    return _client!
        .channel('public:$table')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: table,
          callback: onData,
        )
        .subscribe();
  }

  // Water intake specific methods
  static Future<Map<String, dynamic>?> saveWaterIntake(String deviceId, double glassesCount) async {
    try {
      final response = await insert('water_intakes', {
        'device_id': deviceId,
        'glasses_count': glassesCount,
        'intake_time': DateTime.now().toIso8601String(),
      });
      return response;
    } catch (e) {
      debugPrint('Error saving water intake: $e');
      return null;
    }
  }

  static Future<List<Map<String, dynamic>>> getTodayWaterIntakes(String deviceId) async {
    try {
      if (_client == null) {
        debugPrint('Supabase client not available');
        return [];
      }
      final today = DateTime.now();
      final startOfDay = DateTime(today.year, today.month, today.day);
      final endOfDay = DateTime(today.year, today.month, today.day, 23, 59, 59);
      
      dynamic query = _client!
          .from('water_intakes')
          .select()
          .eq('device_id', deviceId)
          .gte('intake_time', startOfDay.toIso8601String())
          .lte('intake_time', endOfDay.toIso8601String())
          .order('intake_time');
      
      final List<dynamic> response = await query;
      return response.cast<Map<String, dynamic>>();
    } catch (e) {
      debugPrint('Error getting today water intakes: $e');
      return [];
    }
  }

  static Future<double> getTodayTotalGlasses(String deviceId) async {
    try {
      final intakes = await getTodayWaterIntakes(deviceId);
      double total = 0.0;
      for (final intake in intakes) {
        total += (intake['glasses_count'] as num).toDouble();
      }
      return total;
    } catch (e) {
      debugPrint('Error calculating total glasses: $e');
      return 0.0;
    }
  }

  // Notification schedule methods
  static Future<Map<String, dynamic>?> saveNotificationSchedule(
    String deviceId,
    int intervalMinutes,
    {int startHour = 8, int endHour = 22}
  ) async {
    try {
      // First try to update existing schedule
      if (_client == null) {
        debugPrint('Supabase client not available');
        return null;
      }
      final existing = await _client!
          .from('notification_schedules')
          .select()
          .eq('device_id', deviceId)
          .maybeSingle();
      
      if (existing != null) {
        return await update('notification_schedules', {
          'interval_minutes': intervalMinutes,
          'start_hour': startHour,
          'end_hour': endHour,
          'active': true,
        }, 'device_id', deviceId);
      } else {
        return await insert('notification_schedules', {
          'device_id': deviceId,
          'interval_minutes': intervalMinutes,
          'start_hour': startHour,
          'end_hour': endHour,
          'active': true,
        });
      }
    } catch (e) {
      debugPrint('Error saving notification schedule: $e');
      return null;
    }
  }

  static Future<Map<String, dynamic>?> getNotificationSchedule(String deviceId) async {
    try {
      if (_client == null) {
        debugPrint('Supabase client not available');
        return null;
      }
      final response = await _client!
          .from('notification_schedules')
          .select()
          .eq('device_id', deviceId)
          .maybeSingle();
      return response;
    } catch (e) {
      debugPrint('Error getting notification schedule: $e');
      return null;
    }
  }

  // Notification specific methods  
  static Future<String?> createNotificationToken(String deviceId) async {
    try {
      final response = await insert('notification_tokens', {
        'device_id': deviceId,
        'created_at': DateTime.now().toIso8601String(),
        'is_active': true,
      });
      return response?['id']?.toString();
    } catch (e) {
      debugPrint('Error creating notification token: $e');
      return null;
    }
  }

  static Future<bool> sendNotification(String deviceId, String title, String body) async {
    try {
      await insert('notifications', {
        'device_id': deviceId,
        'title': title,
        'body': body,
        'sent_at': DateTime.now().toIso8601String(),
        'delivered': false,
        'notification_type': 'water_reminder',
      });
      return true;
    } catch (e) {
      debugPrint('Error sending notification: $e');
      return false;
    }
  }

  static Future<List<Map<String, dynamic>>> getUndeliveredNotifications(String deviceId) async {
    try {
      if (_client == null) {
        debugPrint('Supabase client not available');
        return [];
      }
      dynamic query = _client!
          .from('notifications')
          .select()
          .eq('device_id', deviceId)
          .eq('delivered', false)
          .order('sent_at');
      
      final List<dynamic> response = await query;
      return response.cast<Map<String, dynamic>>();
    } catch (e) {
      debugPrint('Error getting undelivered notifications: $e');
      return [];
    }
  }

  static Future<void> markNotificationDelivered(String notificationId) async {
    try {
      await update('notifications', {
        'delivered': true,
        'delivered_at': DateTime.now().toIso8601String()
      }, 'id', notificationId);
    } catch (e) {
      debugPrint('Error marking notification as delivered: $e');
    }
  }
}