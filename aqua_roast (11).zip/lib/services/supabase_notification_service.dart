import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:aqua_roast/supabase/supabase_config.dart';
import 'package:aqua_roast/services/insult_service.dart';
import 'package:aqua_roast/services/storage_service.dart';
import 'dart:math';

class SupabaseNotificationService {
  static final FlutterLocalNotificationsPlugin _localNotifications =
      FlutterLocalNotificationsPlugin();
  static bool _initialized = false;
  static String? _deviceId;
  static RealtimeChannel? _notificationChannel;

  static Future<void> init() async {
    if (_initialized || kIsWeb) return;

    try {
      debugPrint('Initializing Supabase Notification Service...');
      
      // Initialize Supabase
      await SupabaseConfig.initialize();
      debugPrint('Supabase initialized successfully');
      
      // Generate unique device ID
      _deviceId = await _getOrCreateDeviceId();
      debugPrint('Device ID: $_deviceId');
      
      // Configure local notifications for foreground handling
      await _initializeLocalNotifications();
      
      // Set up real-time notification listener
      await _setupNotificationListener();
      
      _initialized = true;
      debugPrint('Supabase Notification Service initialized successfully');
    } catch (e) {
      debugPrint('Error initializing Supabase Notification Service: $e');
      _initialized = false;
    }
  }

  static Future<String> _getOrCreateDeviceId() async {
    try {
      // Try to get stored device ID
      String? deviceId = await StorageService.getDeviceId();
      
      if (deviceId == null || deviceId.isEmpty) {
        // Generate a new device ID
        deviceId = 'device_${DateTime.now().millisecondsSinceEpoch}_${Random().nextInt(10000)}';
        await StorageService.saveDeviceId(deviceId);
        debugPrint('Generated new device ID: $deviceId');
      } else {
        debugPrint('Using existing device ID: $deviceId');
      }
      
      return deviceId;
    } catch (e) {
      debugPrint('Error getting/creating device ID: $e');
      // Fallback device ID if storage fails
      return 'device_fallback_${DateTime.now().millisecondsSinceEpoch}';
    }
  }

  static Future<void> _initializeLocalNotifications() async {
    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const DarwinInitializationSettings initializationSettingsDarwin =
        DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    const InitializationSettings initializationSettings =
        InitializationSettings(
      android: initializationSettingsAndroid,
      iOS: initializationSettingsDarwin,
      macOS: initializationSettingsDarwin,
    );

    await _localNotifications.initialize(
      initializationSettings,
      onDidReceiveNotificationResponse: (NotificationResponse response) {
        debugPrint('Local notification tapped: ${response.payload}');
      },
    );
  }

  static Future<void> _setupNotificationListener() async {
    if (_deviceId == null) return;

    try {
      // Listen for real-time notifications
      _notificationChannel = SupabaseService.subscribeToTable('notifications', (payload) {
        debugPrint('Received real-time notification: ${payload.newRecord}');
        
        if (payload.newRecord != null) {
          final notification = payload.newRecord!;
          final deviceId = notification['device_id'] as String?;
          
          // Only process notifications for this device
          if (deviceId == _deviceId) {
            final title = notification['title'] as String? ?? 'Drink, Idiot!';
            final body = notification['body'] as String? ?? InsultService.getReminderInsult();
            final notificationId = notification['id'] as int?;
            
            _showLocalNotification(title, body);
            
            // Mark as delivered
            if (notificationId != null) {
              SupabaseService.markNotificationDelivered(notificationId.toString());
            }
          }
        }
      });

      if (_notificationChannel != null) {
        debugPrint('Notification listener set up successfully');
      } else {
        debugPrint('Failed to set up notification listener - Supabase not available');
      }
    } catch (e) {
      debugPrint('Error setting up notification listener: $e');
    }
  }

  static Future<void> _showLocalNotification(String title, String body) async {
    const AndroidNotificationDetails androidPlatformChannelSpecifics =
        AndroidNotificationDetails(
      'water_reminders_supabase',
      'Water Reminders (Supabase)',
      channelDescription: 'Insulting push notifications via Supabase',
      importance: Importance.high,
      priority: Priority.high,
      icon: '@mipmap/ic_launcher',
      color: Color(0xFFFF9800),
      playSound: true,
      enableVibration: true,
    );

    const DarwinNotificationDetails iOSPlatformChannelSpecifics =
        DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
      sound: 'default',
    );

    const NotificationDetails platformChannelSpecifics = NotificationDetails(
      android: androidPlatformChannelSpecifics,
      iOS: iOSPlatformChannelSpecifics,
      macOS: iOSPlatformChannelSpecifics,
    );

    await _localNotifications.show(
      DateTime.now().millisecondsSinceEpoch.remainder(100000),
      title,
      body,
      platformChannelSpecifics,
    );
  }

  static Future<String?> getDeviceId() async {
    if (!_initialized) {
      await init();
    }
    
    // If still no device ID after init, try to create one manually
    if (_deviceId == null || _deviceId!.isEmpty) {
      _deviceId = await _getOrCreateDeviceId();
    }
    
    return _deviceId;
  }

  static Future<bool> requestPermissions() async {
    if (kIsWeb) return false;

    try {
      if (Platform.isIOS || Platform.isMacOS) {
        return await _localNotifications
                .resolvePlatformSpecificImplementation<
                    IOSFlutterLocalNotificationsPlugin>()
                ?.requestPermissions(
                  alert: true,
                  badge: true,
                  sound: true,
                ) ??
            false;
      } else if (Platform.isAndroid) {
        final AndroidFlutterLocalNotificationsPlugin? androidImplementation =
            _localNotifications.resolvePlatformSpecificImplementation<
                AndroidFlutterLocalNotificationsPlugin>();

        return await androidImplementation?.requestNotificationsPermission() ?? false;
      }
    } catch (e) {
      debugPrint('Error requesting notification permissions: $e');
    }
    return false;
  }

  static Future<bool> sendRemoteNotification(String title, String body) async {
    if (!_initialized || _deviceId == null) return false;

    try {
      return await SupabaseService.sendNotification(_deviceId!, title, body);
    } catch (e) {
      debugPrint('Error sending remote notification: $e');
      return false;
    }
  }

  static Future<String> sendTestPushNotification() async {
    if (!_initialized) {
      await init();
      if (!_initialized) {
        return 'Supabase not initialized. Please check your Supabase configuration.';
      }
    }

    if (_deviceId == null) {
      return 'Device ID not available. Please restart the app.';
    }

    try {
      final insult = InsultService.getReminderInsult();
      final success = await sendRemoteNotification('Drink, Idiot!', insult);

      if (success) {
        return 'Test push notification sent successfully via Supabase!\n\nDevice ID: $_deviceId\n\nNotification: $insult';
      } else {
        return 'Failed to send test notification. Check Supabase configuration.';
      }
    } catch (e) {
      debugPrint('Error sending test push notification: $e');
      return 'Error: ${e.toString()}';
    }
  }

  static Future<void> scheduleRemoteNotifications() async {
    if (!_initialized || _deviceId == null) return;

    try {
      final intervalMinutes = await StorageService.getNotificationInterval();
      debugPrint('Scheduling remote notifications every $intervalMinutes minutes');

      // In a real implementation, you'd set up server-side scheduling
      // For now, we'll create a simple notification record that could trigger server-side logic
      await SupabaseService.insert('notification_schedules', {
        'device_id': _deviceId!,
        'interval_minutes': intervalMinutes,
        'active': true,
        'created_at': DateTime.now().toIso8601String(),
      });

      debugPrint('Notification schedule updated in Supabase');
    } catch (e) {
      debugPrint('Error scheduling remote notifications: $e');
    }
  }

  static Future<void> dispose() async {
    _notificationChannel?.unsubscribe();
    _notificationChannel = null;
  }

  static bool get isInitialized => _initialized;
}