import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:aqua_roast/services/notification_service.dart';

@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // Background handling if needed (avoid heavy work)
}

class FirebasePushService {
  static bool _inited = false;

  static bool get _isMobile => !kIsWeb &&
      (defaultTargetPlatform == TargetPlatform.iOS ||
       defaultTargetPlatform == TargetPlatform.android);

  static bool get _isCupertino => !kIsWeb &&
      (defaultTargetPlatform == TargetPlatform.iOS ||
       defaultTargetPlatform == TargetPlatform.macOS);

  static Future<void> init() async {
    if (_inited) return;

    if (!_isMobile) {
      debugPrint('FirebasePushService: skipping init (not mobile platform)');
      _inited = true; // no-op to avoid repeated attempts on web/desktop
      return;
    }

    try {
      await Firebase.initializeApp();
    } catch (e) {
      debugPrint('FirebasePushService: Firebase.initializeApp failed: $e');
      // On iOS, this usually means the GoogleService-Info.plist is missing.
      // We keep going to avoid crashing preview builds.
    }

    // iOS permission prompt
    if (_isCupertino) {
      final settings = await FirebaseMessaging.instance.requestPermission(
        alert: true,
        badge: true,
        sound: true,
        provisional: false,
      );
      debugPrint('🔔 APNs permission: ${settings.authorizationStatus}');

      // Foreground presentation options
      await FirebaseMessaging.instance.setForegroundNotificationPresentationOptions(
        alert: true,
        badge: true,
        sound: true,
      );
    }

    // Register background handler
    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

    // Foreground messages -> mirror as local notification (time‑sensitive on iOS)
    FirebaseMessaging.onMessage.listen((RemoteMessage message) async {
      try {
        final title = message.notification?.title ?? 'Drink, Idiot!';
        final body = message.notification?.body ?? 'It\'s time to hydrate.';
        await NotificationService.showLocal(title: title, body: body);
      } catch (e) {
        debugPrint('Error showing foreground push as local notification: $e');
      }
    });

    // Opened-from-terminated
    FirebaseMessaging.instance.getInitialMessage().then((message) {
      if (message != null) {
        debugPrint('Opened from terminated via FCM: ${message.data}');
      }
    });

    // Opened-from-background
    FirebaseMessaging.onMessageOpenedApp.listen((message) {
      debugPrint('Opened from background via FCM: ${message.data}');
    });

    // Get and log token
    try {
      final token = await FirebaseMessaging.instance.getToken();
      debugPrint('📬 FCM token: $token');
    } catch (e) {
      debugPrint('Error getting FCM token: $e');
    }

    _inited = true;
  }

  static Future<String?> getToken() async {
    try {
      return await FirebaseMessaging.instance.getToken();
    } catch (e) {
      debugPrint('Error getting FCM token: $e');
      return null;
    }
  }

  static Future<bool> isInitialized() async {
    return _inited;
  }
}