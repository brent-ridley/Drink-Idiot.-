import 'package:purchases_flutter/purchases_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

class RevenueCatService {
  static const String _apiKey = 'appl_lvHdKvvFfkQPSxYqhKElqhcwNpr';
  static const String _entitlementId = 'premium';
  static const String _freePeriodKey = 'free_period_end';
  static const String _firstLaunchKey = 'first_launch_shown';
  
  static Future<void> initialize() async {
    try {
      await Purchases.setLogLevel(LogLevel.debug);
      await Purchases.configure(PurchasesConfiguration(_apiKey));
    } catch (e) {
      print('RevenueCat initialization error: $e');
    }
  }
  
  static Future<bool> isPremium() async {
    try {
      CustomerInfo customerInfo = await Purchases.getCustomerInfo();
      return customerInfo.entitlements.all[_entitlementId]?.isActive ?? false;
    } catch (e) {
      print('Error checking premium status: $e');
      return false;
    }
  }
  
  static Future<bool> isFreePeriodActive() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    int? freePeriodEnd = prefs.getInt(_freePeriodKey);
    
    if (freePeriodEnd == null) {
      // First time user - set 3 day free period
      int threeDaysFromNow = DateTime.now().add(Duration(days: 3)).millisecondsSinceEpoch;
      await prefs.setInt(_freePeriodKey, threeDaysFromNow);
      return true;
    }
    
    return DateTime.now().millisecondsSinceEpoch < freePeriodEnd;
  }
  
  static Future<bool> shouldShowPaywall() async {
    bool isPremiumUser = await isPremium();
    bool isFreePeriodStillActive = await isFreePeriodActive();
    
    return !isPremiumUser && !isFreePeriodStillActive;
  }
  
  static Future<List<StoreProduct>> getOfferings() async {
    try {
      Offerings offerings = await Purchases.getOfferings();
      if (offerings.current != null && offerings.current!.availablePackages.isNotEmpty) {
        return offerings.current!.availablePackages.map((package) => package.storeProduct).toList();
      }
    } catch (e) {
      print('Error fetching offerings: $e');
    }
    return [];
  }
  
  static Future<bool> purchaseProduct(StoreProduct product) async {
    try {
      PurchaseResult result = await Purchases.purchaseStoreProduct(product);
      return result.customerInfo.entitlements.all[_entitlementId]?.isActive ?? false;
    } catch (e) {
      print('Purchase error: $e');
      return false;
    }
  }
  
  static Future<bool> restorePurchases() async {
    try {
      CustomerInfo customerInfo = await Purchases.restorePurchases();
      return customerInfo.entitlements.all[_entitlementId]?.isActive ?? false;
    } catch (e) {
      print('Restore purchases error: $e');
      return false;
    }
  }
  
  static Future<bool> isFirstLaunch() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool hasShown = prefs.getBool(_firstLaunchKey) ?? false;
    return !hasShown;
  }
  
  static Future<void> markFirstLaunchShown() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_firstLaunchKey, true);
  }
  
  static Future<bool> showPaywall() async {
    try {
      // Get the current offerings
      Offerings offerings = await Purchases.getOfferings();
      if (offerings.current != null && offerings.current!.availablePackages.isNotEmpty) {
        // Use the first available package (typically monthly subscription)
        Package package = offerings.current!.availablePackages.first;
        PurchaseResult result = await Purchases.purchasePackage(package);
        return result.customerInfo.entitlements.all[_entitlementId]?.isActive ?? false;
      }
      return false;
    } catch (e) {
      // Handle purchase errors gracefully
      String errorMessage = e.toString();
      print('Purchase error: $errorMessage');
      
      // Check for common error patterns
      if (errorMessage.contains('cancel') || errorMessage.contains('Cancel')) {
        print('Purchase cancelled by user');
      } else if (errorMessage.contains('pending') || errorMessage.contains('Pending')) {
        print('Payment is pending');
      } else if (errorMessage.contains('not available') || errorMessage.contains('NotAvailable')) {
        print('Product not available for purchase');
      } else {
        print('Other purchase error: $errorMessage');
      }
      return false;
    }
  }
  
  static Future<String> getRemainingTrialDays() async {
    try {
      bool isActive = await isFreePeriodActive();
      if (!isActive) return 'Trial Expired';
      
      SharedPreferences prefs = await SharedPreferences.getInstance();
      int? freePeriodEnd = prefs.getInt(_freePeriodKey);
      
      if (freePeriodEnd == null) return 'Trial Expired';
      
      DateTime endDate = DateTime.fromMillisecondsSinceEpoch(freePeriodEnd);
      DateTime now = DateTime.now();
      int daysRemaining = endDate.difference(now).inDays;
      
      if (daysRemaining <= 0) return 'Trial Expired';
      if (daysRemaining == 1) return '1 Day Left';
      return '$daysRemaining Days Left';
    } catch (e) {
      print('Error getting remaining trial days: $e');
      return 'Trial Expired';
    }
  }
}