import 'package:flutter/material.dart';
import 'package:aqua_roast/utils/hydration_colors.dart';

class AddWaterButton extends StatefulWidget {
  final Function(int) onAddWater;
  final int hydrationLevel;

  const AddWaterButton({
    super.key,
    required this.onAddWater,
    required this.hydrationLevel,
  });

  @override
  State<AddWaterButton> createState() => _AddWaterButtonState();
}

class WaterIntakeOption {
  final String name;
  final int ounces;
  final String description;
  final IconData icon;

  const WaterIntakeOption({
    required this.name,
    required this.ounces,
    required this.description,
    required this.icon,
  });
}

class _AddWaterButtonState extends State<AddWaterButton>
    with TickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;
  int _selectedIndex = 0;

  static const List<WaterIntakeOption> _intakeOptions = [
    WaterIntakeOption(
      name: 'A Sip',
      ounces: 1, // Small but meaningful contribution
      description: '~0.5oz',
      icon: Icons.opacity,
    ),
    WaterIntakeOption(
      name: 'Gulp',
      ounces: 2,
      description: '~1-2oz',
      icon: Icons.local_drink_outlined,
    ),
    WaterIntakeOption(
      name: 'Half Cup',
      ounces: 4,
      description: '~4oz',
      icon: Icons.local_cafe,
    ),
    WaterIntakeOption(
      name: '1 Glass',
      ounces: 8,
      description: '~8oz',
      icon: Icons.local_drink,
    ),
    WaterIntakeOption(
      name: '2 Glasses',
      ounces: 16,
      description: '~16oz',
      icon: Icons.sports_bar,
    ),
    WaterIntakeOption(
      name: 'Big Bottle',
      ounces: 20,
      description: '~20oz',
      icon: Icons.water_drop,
    ),
  ];

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 150),
      vsync: this,
    );
    _scaleAnimation = Tween<double>(
      begin: 1.0,
      end: 0.95,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _onButtonPressed() async {
    await _animationController.forward();
    await _animationController.reverse();
    widget.onAddWater(_intakeOptions[_selectedIndex].ounces);
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Add Water Intake',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            Text(
              'Choose your intake amount:',
              style: Theme.of(context).textTheme.bodyMedium,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 100,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: _intakeOptions.length,
                itemBuilder: (context, index) => Padding(
                  padding: EdgeInsets.only(
                    left: index == 0 ? 8 : 4,
                    right: index == _intakeOptions.length - 1 ? 8 : 4,
                  ),
                  child: _buildIntakeSelector(index),
                ),
              ),
            ),
            const SizedBox(height: 20),
            ScaleTransition(
              scale: _scaleAnimation,
              child: ElevatedButton.icon(
                onPressed: _onButtonPressed,
                icon: Icon(
                  _intakeOptions[_selectedIndex].icon,
                  color: HydrationColors.getOnPrimaryColor(widget.hydrationLevel),
                ),
                label: Text(
                  'Add ${_intakeOptions[_selectedIndex].name}',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: HydrationColors.getOnPrimaryColor(widget.hydrationLevel),
                    fontWeight: FontWeight.bold,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: HydrationColors.getPrimaryColor(widget.hydrationLevel),
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              _intakeOptions[_selectedIndex].description,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.6),
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildIntakeSelector(int index) {
    final option = _intakeOptions[index];
    final isSelected = _selectedIndex == index;
    
    return GestureDetector(
      onTap: () => setState(() => _selectedIndex = index),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: 80,
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: isSelected 
              ? HydrationColors.getPrimaryColor(widget.hydrationLevel)
              : Theme.of(context).colorScheme.surface,
          border: Border.all(
            color: isSelected 
                ? HydrationColors.getPrimaryColor(widget.hydrationLevel)
                : Theme.of(context).colorScheme.outline,
            width: 2,
          ),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              option.icon,
              color: isSelected 
                  ? HydrationColors.getOnPrimaryColor(widget.hydrationLevel)
                  : Theme.of(context).colorScheme.onSurface,
              size: 24,
            ),
            const SizedBox(height: 4),
            Text(
              option.name,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: isSelected 
                    ? HydrationColors.getOnPrimaryColor(widget.hydrationLevel)
                    : Theme.of(context).colorScheme.onSurface,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            Text(
              option.description,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: isSelected 
                    ? HydrationColors.getOnPrimaryColor(widget.hydrationLevel).withValues(alpha: 0.8)
                    : Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.6),
                fontSize: 10,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}