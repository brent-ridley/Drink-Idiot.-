import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'dart:async';
import 'package:purchases_ui_flutter/purchases_ui_flutter.dart';
import 'package:aqua_roast/models/water_intake.dart';
import 'package:aqua_roast/services/storage_service.dart';
import 'package:aqua_roast/services/insult_service.dart';
import 'package:aqua_roast/services/notification_service.dart';
import 'package:aqua_roast/services/supabase_notification_service.dart';
import 'package:aqua_roast/services/revenue_cat_service.dart';
import 'package:aqua_roast/widgets/animated_glass_widget.dart';
import 'package:aqua_roast/widgets/insult_card_widget.dart';
import 'package:aqua_roast/widgets/add_water_button.dart';
import 'package:aqua_roast/screens/settings_screen.dart';
import 'package:aqua_roast/screens/subscription_screen.dart';
import 'package:aqua_roast/utils/hydration_colors.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  DailyProgress? _progress;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _initializeApp();
  }

  Future<void> _initializeApp() async {
    try {
      await StorageService.init();
      await StorageService.checkAndResetDaily();
      await _loadProgress();
      
      // Show trial popup on first launch with error handling
      if (mounted) {
        try {
          await _showTrialPopupIfNeeded();
        } catch (e) {
          print('Error showing trial popup: $e');
        }
      }
      
      // Check if we should show paywall after loading progress
      if (mounted) {
        try {
          unawaited(_checkPaywall());
        } catch (e) {
          print('Error checking paywall: $e');
        }
      }
    } catch (e) {
      print('Error initializing app: $e');
      // Set basic defaults if initialization fails
      if (mounted) {
        setState(() {
          _progress = DailyProgress(
            date: DateTime.now(),
            totalGlasses: 0.0,
            dailyGoal: 8,
            intakes: [],
          );
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _checkPaywall() async {
    try {
      bool shouldShow = await RevenueCatService.shouldShowPaywall();
      if (shouldShow && mounted) {
        // Show paywall after a brief delay
        unawaited(Future.delayed(const Duration(seconds: 1), () {
          if (mounted) {
            try {
              _showPaywall();
            } catch (e) {
              print('Error showing paywall: $e');
            }
          }
        }));
      }
    } catch (e) {
      print('Error checking paywall: $e');
    }
  }

  Future<void> _showTrialPopupIfNeeded() async {
    try {
      // Try RevenueCat first, but fallback to local storage if it fails
      bool isFirstLaunch;
      try {
        isFirstLaunch = await RevenueCatService.isFirstLaunch();
      } catch (e) {
        print('RevenueCat first launch check failed: $e, using local storage fallback');
        // Fallback to local storage
        final prefs = await StorageService.getPrefs();
        isFirstLaunch = !(prefs.getBool('first_launch_shown') ?? false);
      }
      
      if (isFirstLaunch && mounted) {
        // Mark as shown using both RevenueCat and local storage
        try {
          await RevenueCatService.markFirstLaunchShown();
        } catch (e) {
          print('RevenueCat mark first launch failed: $e');
        }
        
        // Always use local storage as backup
        final prefs = await StorageService.getPrefs();
        await prefs.setBool('first_launch_shown', true);
        
        // Show trial popup after a brief delay to ensure UI is ready
        unawaited(Future.delayed(const Duration(milliseconds: 500), () {
          if (mounted) {
            try {
              _showTrialPopup();
            } catch (e) {
              print('Error showing trial popup: $e');
            }
          }
        }));
      }
    } catch (e) {
      print('Error checking first launch: $e');
    }
  }

  Future<void> _showTrialPopup() async {
    if (!mounted) return;
    
    try {
      await showDialog(
        context: context,
        barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          title: Text(
            'Welcome to Drink, Idiot!',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                '🎉 Start your 3-day FREE trial now!',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              Text(
                'After your free trial, continue getting hydration reminders and insulting motivation for just \$2.99/month.',
                style: Theme.of(context).textTheme.bodyMedium,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              Text(
                '💧 Unlimited water tracking\n'
                '🎯 Personalized hydration goals\n'
                '📱 Smart reminder notifications\n'
                '💬 Premium insults & encouragement',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.8),
                ),
                textAlign: TextAlign.left,
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text(
                'Start Free Trial',
                style: TextStyle(
                  color: Theme.of(context).colorScheme.primary,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ),
          ],
        );
      },
    );
    } catch (e) {
      print('Error in trial popup: $e');
    }
  }

  Future<void> _showPaywall() async {
    if (!mounted) return;

    try {
      if (kIsWeb) {
        // Fallback to the custom screen in web preview
        await Navigator.of(context).push<bool>(
          MaterialPageRoute(
            builder: (context) => const SubscriptionScreen(),
            fullscreenDialog: true,
          ),
        );
        return;
      }

      await RevenueCatUI.presentPaywall();

      // Optionally refresh UI/state after returning
      final premium = await RevenueCatService.isPremium();
      if (premium) {
        // Purchased successfully; you could update any gated UI here if needed
        debugPrint('User purchased premium via paywall');
      }
    } catch (e) {
      debugPrint('Error showing paywall: $e');
    }
  }

  Future<void> _loadProgress() async {
    try {
      final progress = await StorageService.getTodaysProgress();
      setState(() {
        _progress = progress;
        _isLoading = false;
      });
    } catch (e) {
      print('Error loading progress: $e');
      // Create default progress if loading fails
      setState(() {
        _progress = DailyProgress(
          date: DateTime.now(),
          totalGlasses: 0.0,
          dailyGoal: 8,
          intakes: [],
        );
        _isLoading = false;
      });
    }
  }


  Future<void> _addWater(int ounces) async {
    // Convert ounces to glasses (8 oz = 1 glass)
    final glassesEquivalent = (ounces / 8.0).clamp(0.0625, 20.0); // Minimum 0.0625 (half ounce)
    
    final intake = WaterIntake(
      timestamp: DateTime.now(),
      glassesCount: glassesEquivalent,
    );
    
    await StorageService.addWaterIntake(intake);
    await _loadProgress();
    
    // Refresh notification schedule to keep reminders current
    await NotificationService.scheduleWaterReminders();
    
    // Update Supabase notification schedule
    try {
      await SupabaseNotificationService.scheduleRemoteNotifications();
    } catch (e) {
      debugPrint('Error updating Supabase notification schedule: $e');
    }
    
    // Show success message with ounces
    String message;
    if (ounces < 8) {
      message = 'Added ${ounces}oz of water!';
    } else if (glassesEquivalent == glassesEquivalent.round()) {
      final glassText = glassesEquivalent.round() == 1 ? 'glass' : 'glasses';
      message = 'Added ${glassesEquivalent.round()} $glassText (${ounces}oz) of water!';
    } else {
      message = 'Added ${glassesEquivalent.toStringAsFixed(1)} glasses (${ounces}oz) of water!';
    }
    
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          duration: const Duration(seconds: 2),
        ),
      );
    }
  }

  void _navigateToSettings() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const SettingsScreen()),
    ).then((_) {
      _loadProgress();
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading || _progress == null) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('DRINK, IDIOT'),
          centerTitle: true,
          backgroundColor: Colors.orange,
        ),
        body: const Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 20),
              Text('Loading your water tracking...'),
            ],
          ),
        ),
      );
    }

    final progress = _progress;
    if (progress == null) {
      return const Scaffold(
        body: Center(child: Text('Error loading data')),
      );
    }
    final hydrationLevel = progress.hydrationLevel;
    final currentInsult = InsultService.getInsultForLevel(hydrationLevel);
    
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'DRINK, IDIOT',
          style: Theme.of(context).textTheme.headlineMedium?.copyWith(
            color: HydrationColors.getOnPrimaryColor(hydrationLevel),
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
        backgroundColor: HydrationColors.getPrimaryColor(hydrationLevel),
        actions: [
          IconButton(
            icon: Icon(
              Icons.settings,
              color: HydrationColors.getOnPrimaryColor(hydrationLevel),
            ),
            onPressed: _navigateToSettings,
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            AnimatedGlassWidget(progress: progress),
            const SizedBox(height: 24),
            InsultCardWidget(
              insult: currentInsult,
              hydrationLevel: progress.hydrationLevel,
            ),
            const SizedBox(height: 24),
            AddWaterButton(
              onAddWater: _addWater,
              hydrationLevel: progress.hydrationLevel,
            ),
            const SizedBox(height: 24),
            _buildTodaysIntakes(progress.intakes, progress.hydrationLevel),
          ],
        ),
      ),
    );
  }

  Widget _buildTodaysIntakes(List<WaterIntake> intakes, int hydrationLevel) {
    if (intakes.isEmpty) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              Icon(
                Icons.local_drink,
                size: 48,
                color: Theme.of(context).colorScheme.primary.withValues(alpha: 0.5),
              ),
              const SizedBox(height: 8),
              Text(
                'No water logged today',
                style: Theme.of(context).textTheme.bodyLarge,
              ),
              Text(
                'Start drinking, you dehydrated disaster!',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
                ),
              ),
            ],
          ),
        ),
      );
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Today\'s Water Intake',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 12),
            ...intakes.reversed.take(5).map((intake) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 4.0),
              child: Row(
                children: [
                  Icon(
                    Icons.local_drink,
                    size: 20,
                    color: HydrationColors.getPrimaryColor(hydrationLevel),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    intake.glassesCount == intake.glassesCount.round()
                        ? '${intake.glassesCount.round()} glass${intake.glassesCount > 1 ? 'es' : ''}'
                        : '${intake.glassesCount.toStringAsFixed(1)} glasses',
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                  const Spacer(),
                  Text(
                    _formatTime(intake.timestamp),
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
                    ),
                  ),
                ],
              ),
            )),
            if (intakes.length > 5)
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Text(
                  '... and ${intakes.length - 5} more',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  String _formatTime(DateTime time) {
    final hour = time.hour;
    final minute = time.minute.toString().padLeft(2, '0');
    final period = hour >= 12 ? 'PM' : 'AM';
    final displayHour = hour > 12 ? hour - 12 : (hour == 0 ? 12 : hour);
    return '$displayHour:$minute $period';
  }
}