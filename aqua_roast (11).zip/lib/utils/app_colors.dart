import 'package:flutter/material.dart';

class AppColors {
  static const MaterialColor emerald = MaterialColor(
    0xFF059669,
    <int, Color>{
      50: Color(0xFFECFDF5),
      100: Color(0xFFD1FAE5),
      200: Color(0xFFA7F3D0),
      300: Color(0xFF6EE7B7),
      400: Color(0xFF34D399),
      500: Color(0xFF10B981),
      600: Color(0xFF059669),
      700: Color(0xFF047857),
      800: Color(0xFF065F46),
      900: Color(0xFF064E3B),
    },
  );

  // Orange theme colors for the app
  static const Color primary = Color(0xFFFF9500);
  static const Color background = Color(0xFFFFF8E1);
  static const Color secondary = Color(0xFFFFB74D);
}