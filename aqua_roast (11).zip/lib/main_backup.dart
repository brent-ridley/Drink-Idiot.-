import 'package:flutter/material.dart';
import 'package:aqua_roast/theme.dart';
import 'package:aqua_roast/screens/home_screen.dart';
import 'package:aqua_roast/services/storage_service.dart';
import 'package:aqua_roast/services/notification_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize services
  await StorageService.init();
  await NotificationService.init();
  
  // Request notification permissions
  await NotificationService.requestPermissions();
  
  // Schedule initial water reminders
  await NotificationService.scheduleWaterReminders();
  
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Drink, Idiot',
      debugShowCheckedModeBanner: false,
      theme: lightTheme,
      darkTheme: darkTheme,
      themeMode: ThemeMode.system,
      home: const HomeScreen(),
    );
  }
}