import 'package:flutter/material.dart';
import 'package:aqua_roast/utils/app_colors.dart';

class HydrationColors {
  /// Gets the primary color for a hydration level (used for UI elements)
  static Color getPrimaryColor(int level) {
    switch (level) {
      case 0:
        return Colors.red.shade600;
      case 1:
        return Colors.orange.shade600;
      case 2:
        return Colors.amber.shade600;
      case 3:
        return Colors.blue.shade600;
      case 4:
        return Colors.green.shade600;
      case 5:
        return AppColors.emerald.shade600;
      default:
        return Colors.blue.shade600;
    }
  }

  /// Gets the water color for a hydration level (used in glass animation)
  static Color getWaterColor(int level) {
    switch (level) {
      case 0:
        return Colors.red.shade300;
      case 1:
        return Colors.orange.shade300;
      case 2:
        return Colors.amber.shade300;
      case 3:
        return Colors.blue.shade300;
      case 4:
        return Colors.green.shade300;
      case 5:
        return Colors.cyan.shade300;
      default:
        return Colors.blue.shade300;
    }
  }

  /// Gets a lighter shade for containers/backgrounds
  static Color getLightColor(int level) {
    switch (level) {
      case 0:
        return Colors.red.shade100;
      case 1:
        return Colors.orange.shade100;
      case 2:
        return Colors.amber.shade100;
      case 3:
        return Colors.blue.shade100;
      case 4:
        return Colors.green.shade100;
      case 5:
        return Colors.cyan.shade100;
      default:
        return Colors.blue.shade100;
    }
  }

  /// Gets a darker shade for emphasis
  static Color getDarkColor(int level) {
    switch (level) {
      case 0:
        return Colors.red.shade800;
      case 1:
        return Colors.orange.shade800;
      case 2:
        return Colors.amber.shade800;
      case 3:
        return Colors.blue.shade800;
      case 4:
        return Colors.green.shade800;
      case 5:
        return AppColors.emerald.shade800;
      default:
        return Colors.blue.shade800;
    }
  }

  /// Gets the appropriate text color (white/black) for the hydration level background
  static Color getOnPrimaryColor(int level) {
    // All hydration colors work well with white text
    return Colors.white;
  }
}