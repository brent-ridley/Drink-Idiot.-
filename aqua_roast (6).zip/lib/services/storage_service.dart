import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:aqua_roast/models/water_intake.dart';

class StorageService {
  static const String _dailyGoalKey = 'daily_goal';
  static const String _intakeDataKey = 'intake_data';
  static const String _lastResetDateKey = 'last_reset_date';
  static const String _notificationIntervalKey = 'notification_interval';
  static const String _deviceIdKey = 'device_id';

  static SharedPreferences? _prefs;

  static Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  static SharedPreferences get prefs {
    if (_prefs == null) {
      throw Exception('StorageService not initialized. Call init() first.');
    }
    return _prefs!;
  }

  static Future<SharedPreferences> getPrefs() async {
    if (_prefs == null) {
      await init();
    }
    return _prefs!;
  }

  static Future<int> getDailyGoal() async {
    return prefs.getInt(_dailyGoalKey) ?? 8; // Default 8 glasses
  }

  static Future<void> setDailyGoal(int goal) async {
    await prefs.setInt(_dailyGoalKey, goal);
  }

  static Future<int> getNotificationInterval() async {
    return prefs.getInt(_notificationIntervalKey) ?? 60; // Default 60 minutes
  }

  static Future<void> setNotificationInterval(int intervalMinutes) async {
    await prefs.setInt(_notificationIntervalKey, intervalMinutes);
  }

  static Future<String?> getDeviceId() async {
    return prefs.getString(_deviceIdKey);
  }

  static Future<void> saveDeviceId(String deviceId) async {
    await prefs.setString(_deviceIdKey, deviceId);
  }

  static Future<List<WaterIntake>> getTodaysIntakes() async {
    final today = DateTime.now();
    final todayString = _dateToString(today);
    final data = prefs.getString('${_intakeDataKey}_$todayString');
    
    if (data == null) return [];
    
    final List<dynamic> jsonList = json.decode(data);
    return jsonList.map((json) => WaterIntake.fromMap(json)).toList();
  }

  static Future<void> addWaterIntake(WaterIntake intake) async {
    final intakes = await getTodaysIntakes();
    intakes.add(intake);
    
    final today = DateTime.now();
    final todayString = _dateToString(today);
    final data = json.encode(intakes.map((i) => i.toMap()).toList());
    
    await prefs.setString('${_intakeDataKey}_$todayString', data);
  }

  static Future<DailyProgress> getTodaysProgress() async {
    final today = DateTime.now();
    final intakes = await getTodaysIntakes();
    final goal = await getDailyGoal();
    
    double totalGlasses = 0.0;
    for (final intake in intakes) {
      final glassCount = intake.glassesCount;
      if (glassCount > 0 && glassCount.isFinite) {
        totalGlasses += glassCount;
      }
    }

    return DailyProgress(
      date: today,
      totalGlasses: totalGlasses.clamp(0.0, 1000.0), // Reasonable upper bound
      dailyGoal: goal.clamp(1, 50), // Ensure goal is always positive
      intakes: intakes,
    );
  }

  static Future<void> checkAndResetDaily() async {
    final today = DateTime.now();
    final lastResetString = prefs.getString(_lastResetDateKey);
    
    if (lastResetString != null) {
      final lastReset = DateTime.parse(lastResetString);
      if (_isSameDay(today, lastReset)) {
        return; // Already reset today
      }
    }
    
    // New day detected, save the reset date
    await prefs.setString(_lastResetDateKey, today.toIso8601String());
  }

  static String _dateToString(DateTime date) {
    return '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
  }

  static bool _isSameDay(DateTime date1, DateTime date2) {
    return date1.year == date2.year &&
           date1.month == date2.month &&
           date1.day == date2.day;
  }

  static Future<void> clearAllData() async {
    await prefs.clear();
  }
}