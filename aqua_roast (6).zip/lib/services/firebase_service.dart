// This file has been replaced by Supabase notification service
// Delete this file - it's no longer used