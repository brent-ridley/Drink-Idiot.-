import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tz;
import 'package:aqua_roast/services/insult_service.dart';
import 'package:aqua_roast/services/storage_service.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _notifications =
      FlutterLocalNotificationsPlugin();
  
  static bool _initialized = false;

  static Future<void> init() async {
    if (_initialized || kIsWeb) return;
    
    // Initialize timezone data
    tz.initializeTimeZones();
    
    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const DarwinInitializationSettings initializationSettingsDarwin =
        DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    const InitializationSettings initializationSettings =
        InitializationSettings(
      android: initializationSettingsAndroid,
      iOS: initializationSettingsDarwin,
      macOS: initializationSettingsDarwin,
    );

    await _notifications.initialize(
      initializationSettings,
      onDidReceiveNotificationResponse: (NotificationResponse response) {
        // Handle notification tap if needed
        debugPrint('Notification tapped: ${response.payload}');
      },
    );

    _initialized = true;
  }

  static Future<bool> requestPermissions() async {
    // Return false for web platforms since notifications aren't supported
    if (kIsWeb) return false;
    
    try {
      if (Platform.isIOS || Platform.isMacOS) {
        return await _notifications
                .resolvePlatformSpecificImplementation<
                    IOSFlutterLocalNotificationsPlugin>()
                ?.requestPermissions(
                  alert: true,
                  badge: true,
                  sound: true,
                ) ??
            false;
      } else if (Platform.isAndroid) {
        final AndroidFlutterLocalNotificationsPlugin? androidImplementation =
            _notifications.resolvePlatformSpecificImplementation<
                AndroidFlutterLocalNotificationsPlugin>();

        return await androidImplementation?.requestNotificationsPermission() ?? false;
      }
    } catch (e) {
      debugPrint('Error requesting notification permissions: $e');
    }
    return false;
  }

  static Future<void> scheduleWaterReminders() async {
    // Skip notifications on web platforms
    if (kIsWeb) return;
    
    await init();
    
    // Cancel all existing notifications
    await _notifications.cancelAll();
    
    // Get current notification interval
    final intervalMinutes = await StorageService.getNotificationInterval();
    
    // Schedule repeating notifications throughout the day
    final now = DateTime.now();
    final startOfDay = DateTime(now.year, now.month, now.day, 8, 0); // Start at 8 AM
    final endOfDay = DateTime(now.year, now.month, now.day, 22, 0); // End at 10 PM
    
    int notificationId = 1;
    DateTime nextNotification = startOfDay;
    
    // If it's already past start time today, start from next interval
    if (now.isAfter(startOfDay)) {
      nextNotification = now.add(Duration(minutes: intervalMinutes));
    }
    
    // Schedule notifications for the next 7 days
    for (int day = 0; day < 7; day++) {
      final dayStart = DateTime(
        startOfDay.year, 
        startOfDay.month, 
        startOfDay.day + day, 
        8, 
        0
      );
      final dayEnd = DateTime(
        endOfDay.year, 
        endOfDay.month, 
        endOfDay.day + day, 
        22, 
        0
      );
      
      DateTime currentTime = dayStart;
      
      while (currentTime.isBefore(dayEnd)) {
        if (currentTime.isAfter(DateTime.now())) {
          await _scheduleNotification(
            notificationId++,
            currentTime,
            intervalMinutes,
          );
        }
        currentTime = currentTime.add(Duration(minutes: intervalMinutes));
      }
    }
  }

  static Future<void> _scheduleNotification(
    int id,
    DateTime scheduledDate,
    int intervalMinutes,
  ) async {
    // Get a random insult for the notification
    final insult = InsultService.getReminderInsult();
    
    const AndroidNotificationDetails androidPlatformChannelSpecifics =
        AndroidNotificationDetails(
      'water_reminders',
      'Water Reminders',
      channelDescription: 'Insulting reminders to drink water',
      importance: Importance.high,
      priority: Priority.high,
      icon: '@mipmap/ic_launcher',
      color: const Color(0xFFFF9800), // Orange color matching app theme
      playSound: true,
      enableVibration: true,
    );

    const DarwinNotificationDetails iOSPlatformChannelSpecifics =
        DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
      sound: 'default',
    );

    const NotificationDetails platformChannelSpecifics = NotificationDetails(
      android: androidPlatformChannelSpecifics,
      iOS: iOSPlatformChannelSpecifics,
      macOS: iOSPlatformChannelSpecifics,
    );

    await _notifications.zonedSchedule(
      id,
      'Drink, Idiot!',
      insult,
      tz.TZDateTime.from(scheduledDate, tz.local),
      platformChannelSpecifics,
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
    );
  }

  static Future<void> cancelAllNotifications() async {
    if (kIsWeb) return;
    await _notifications.cancelAll();
  }

  static Future<String> showImmediateInsult() async {
    if (kIsWeb) return 'Notifications not supported on web';
    
    try {
      await init();
      
      // Check if notifications are enabled
      bool hasPermissions = false;
      try {
        hasPermissions = await requestPermissions();
      } catch (e) {
        debugPrint('Permission check failed: $e');
        return 'Please enable notifications in Settings app';
      }
      
      if (!hasPermissions) {
        return 'Please enable notifications in Settings app';
      }
      
      final insult = InsultService.getReminderInsult();
      
      const AndroidNotificationDetails androidPlatformChannelSpecifics =
          AndroidNotificationDetails(
        'water_reminders',
        'Water Reminders',
        channelDescription: 'Insulting reminders to drink water',
        importance: Importance.high,
        priority: Priority.high,
        icon: '@mipmap/ic_launcher',
        color: const Color(0xFFFF9800),
        playSound: true,
        enableVibration: true,
      );

      const DarwinNotificationDetails iOSPlatformChannelSpecifics =
          DarwinNotificationDetails(
        presentAlert: true,
        presentBadge: true,
        presentSound: true,
        sound: 'default',
      );

      const NotificationDetails platformChannelSpecifics = NotificationDetails(
        android: androidPlatformChannelSpecifics,
        iOS: iOSPlatformChannelSpecifics,
        macOS: iOSPlatformChannelSpecifics,
      );

      await _notifications.show(
        0,
        'Drink, Idiot!',
        insult,
        platformChannelSpecifics,
      );
      
      return 'Test notification sent successfully!';
    } catch (e) {
      debugPrint('Error showing test notification: $e');
      return 'Error: ${e.toString()}';
    }
  }

  static Future<List<PendingNotificationRequest>> getPendingNotifications() async {
    if (kIsWeb) return [];
    return await _notifications.pendingNotificationRequests();
  }

  static Future<bool> areNotificationsEnabled() async {
    if (kIsWeb) return false;
    
    try {
      await init();
      
      if (Platform.isIOS || Platform.isMacOS) {
        // For iOS, check the count of pending notifications
        // If we can schedule notifications, we have permission
        final pendingNotifications = await _notifications.pendingNotificationRequests();
        
        // If there are pending notifications, permissions were granted
        if (pendingNotifications.isNotEmpty) {
          return true;
        }
        
        // Try a simple permission check without triggering a dialog
        final iosImplementation = _notifications
            .resolvePlatformSpecificImplementation<
                IOSFlutterLocalNotificationsPlugin>();
                
        if (iosImplementation == null) return false;
        
        // Get notification app launch details to check if notifications were enabled
        final launchDetails = await _notifications.getNotificationAppLaunchDetails();
        
        // If we've ever received a notification, permissions are likely granted
        if (launchDetails?.didNotificationLaunchApp == true) {
          return true;
        }
        
        // As a fallback, assume true if we can't determine (better UX)
        // Since the user mentioned they have notifications enabled
        return true;
      } else if (Platform.isAndroid) {
        final AndroidFlutterLocalNotificationsPlugin? androidImplementation =
            _notifications.resolvePlatformSpecificImplementation<
                AndroidFlutterLocalNotificationsPlugin>();
                
        return await androidImplementation?.areNotificationsEnabled() ?? false;
      }
    } catch (e) {
      debugPrint('Error checking notification status: $e');
    }
    return false;
  }
}