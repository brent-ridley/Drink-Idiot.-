import 'package:flutter/foundation.dart';
import 'package:aqua_roast/supabase/supabase_config.dart';
import 'package:aqua_roast/models/water_intake.dart';
import 'package:aqua_roast/services/storage_service.dart';

class SupabaseWaterService {
  static Future<String> get _deviceId async {
    final deviceId = await StorageService.getDeviceId();
    return deviceId ?? 'default-device';
  }

  /// Save a water intake to both local storage and Supabase
  static Future<bool> addWaterIntake(double glassesCount) async {
    try {
      // Always save locally first for offline support
      final intake = WaterIntake(
        timestamp: DateTime.now(),
        glassesCount: glassesCount,
      );
      await StorageService.addWaterIntake(intake);

      // Try to save to Supabase if available
      if (SupabaseConfig.isInitialized) {
        try {
          final deviceId = await _deviceId;
          await SupabaseService.saveWaterIntake(deviceId, glassesCount);
          debugPrint('Water intake saved to Supabase');
        } catch (e) {
          debugPrint('Failed to save water intake to Supabase: $e');
          // Local save still succeeded, so we don't fail the operation
        }
      }

      return true;
    } catch (e) {
      debugPrint('Error adding water intake: $e');
      return false;
    }
  }

  /// Get today's total glasses with fallback to local storage
  static Future<double> getTodayTotalGlasses() async {
    try {
      // Try Supabase first if available
      if (SupabaseConfig.isInitialized) {
        try {
          final deviceId = await _deviceId;
          final supabaseTotal = await SupabaseService.getTodayTotalGlasses(deviceId);
          debugPrint('Got total glasses from Supabase: $supabaseTotal');
          return supabaseTotal;
        } catch (e) {
          debugPrint('Failed to get total from Supabase, falling back to local: $e');
        }
      }

      // Fallback to local storage
      final intakes = await StorageService.getTodaysIntakes();
      double total = 0.0;
      for (final intake in intakes) {
        total += intake.glassesCount;
      }
      debugPrint('Got total glasses from local storage: $total');
      return total;
    } catch (e) {
      debugPrint('Error getting today total glasses: $e');
      return 0.0;
    }
  }

  /// Get today's water intakes with fallback to local storage
  static Future<List<WaterIntake>> getTodayWaterIntakes() async {
    try {
      // Try Supabase first if available
      if (SupabaseConfig.isInitialized) {
        try {
          final deviceId = await _deviceId;
          final supabaseData = await SupabaseService.getTodayWaterIntakes(deviceId);
          final intakes = supabaseData.map((data) {
            return WaterIntake(
              timestamp: DateTime.parse(data['intake_time']),
              glassesCount: (data['glasses_count'] as num).toDouble(),
            );
          }).toList();
          debugPrint('Got ${intakes.length} intakes from Supabase');
          return intakes;
        } catch (e) {
          debugPrint('Failed to get intakes from Supabase, falling back to local: $e');
        }
      }

      // Fallback to local storage
      final intakes = await StorageService.getTodaysIntakes();
      debugPrint('Got ${intakes.length} intakes from local storage');
      return intakes;
    } catch (e) {
      debugPrint('Error getting today water intakes: $e');
      return [];
    }
  }

  /// Sync local data to Supabase (for when connection is restored)
  static Future<void> syncLocalToSupabase() async {
    if (!SupabaseConfig.isInitialized) return;

    try {
      final localIntakes = await StorageService.getTodaysIntakes();
      final deviceId = await _deviceId;
      
      for (final intake in localIntakes) {
        try {
          await SupabaseService.saveWaterIntake(deviceId, intake.glassesCount);
          debugPrint('Synced local intake to Supabase: ${intake.glassesCount} glasses');
        } catch (e) {
          debugPrint('Failed to sync intake to Supabase: $e');
        }
      }
    } catch (e) {
      debugPrint('Error syncing to Supabase: $e');
    }
  }

  /// Save notification schedule to Supabase
  static Future<bool> saveNotificationSchedule(int intervalMinutes) async {
    if (!SupabaseConfig.isInitialized) return false;

    try {
      final deviceId = await _deviceId;
      await SupabaseService.saveNotificationSchedule(deviceId, intervalMinutes);
      debugPrint('Notification schedule saved to Supabase: $intervalMinutes minutes');
      return true;
    } catch (e) {
      debugPrint('Error saving notification schedule: $e');
      return false;
    }
  }

  /// Get notification schedule from Supabase
  static Future<int?> getNotificationSchedule() async {
    if (!SupabaseConfig.isInitialized) return null;

    try {
      final deviceId = await _deviceId;
      final schedule = await SupabaseService.getNotificationSchedule(deviceId);
      final intervalMinutes = schedule?['interval_minutes'] as int?;
      debugPrint('Got notification schedule from Supabase: $intervalMinutes minutes');
      return intervalMinutes;
    } catch (e) {
      debugPrint('Error getting notification schedule: $e');
      return null;
    }
  }
}