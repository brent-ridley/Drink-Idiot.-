/// Example service showing how to use Supabase client for your Drink, Idiot app
/// This file demonstrates various Supabase operations and can be used as reference
/// 
/// DO NOT USE THIS FILE IN PRODUCTION - IT'S FOR REFERENCE ONLY

import 'package:flutter/foundation.dart';
import 'package:aqua_roast/supabase/supabase_config.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class SupabaseClientExample {
  // Example: Simple data operations
  static Future<void> exampleBasicOperations() async {
    if (!SupabaseConfig.isInitialized) {
      debugPrint('Supabase not initialized');
      return;
    }

    final client = SupabaseConfig.client;
    if (client == null) {
      debugPrint('Supabase client not available');
      return;
    }

    try {
      // Example 1: Insert water intake
      final insertResult = await client
          .from('water_intakes')
          .insert({
            'device_id': 'example-device-123',
            'glasses_count': 2.0,
            'intake_time': DateTime.now().toIso8601String(),
          })
          .select()
          .single();
      
      debugPrint('Inserted water intake: ${insertResult['id']}');

      // Example 2: Get today's water intakes
      final today = DateTime.now();
      final startOfDay = DateTime(today.year, today.month, today.day);
      final endOfDay = DateTime(today.year, today.month, today.day, 23, 59, 59);

      final todayIntakes = await client
          .from('water_intakes')
          .select()
          .eq('device_id', 'example-device-123')
          .gte('intake_time', startOfDay.toIso8601String())
          .lte('intake_time', endOfDay.toIso8601String())
          .order('intake_time');

      debugPrint('Today\'s intakes: ${todayIntakes.length}');

      // Example 3: Update notification schedule
      await client
          .from('notification_schedules')
          .upsert({
            'device_id': 'example-device-123',
            'interval_minutes': 60,
            'active': true,
          });

      debugPrint('Updated notification schedule');

      // Example 4: Get undelivered notifications
      final notifications = await client
          .from('notifications')
          .select()
          .eq('device_id', 'example-device-123')
          .eq('delivered', false)
          .order('sent_at');

      debugPrint('Undelivered notifications: ${notifications.length}');

    } catch (e) {
      debugPrint('Error in Supabase operations: $e');
    }
  }

  // Example: Real-time subscriptions
  static void exampleRealtimeSubscription() {
    if (!SupabaseConfig.isInitialized) return;

    final client = SupabaseConfig.client;
    if (client == null) {
      debugPrint('Supabase client not available');
      return;
    }

    // Subscribe to water_intakes table changes
    client
        .channel('water_intakes_changes')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'water_intakes',
          callback: (payload) {
            debugPrint('New water intake added: ${payload.newRecord}');
            // Handle new water intake in your UI
          },
        )
        .subscribe();

    // Subscribe to notification changes
    client
        .channel('notification_changes')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'notifications',
          callback: (payload) {
            switch (payload.eventType) {
              case PostgresChangeEvent.insert:
                debugPrint('New notification: ${payload.newRecord}');
                break;
              case PostgresChangeEvent.update:
                debugPrint('Updated notification: ${payload.newRecord}');
                break;
              case PostgresChangeEvent.delete:
                debugPrint('Deleted notification: ${payload.oldRecord}');
                break;
              case PostgresChangeEvent.all:
                debugPrint('All notification events: ${payload.newRecord}');
                break;
            }
          },
        )
        .subscribe();
  }

  // Example: Advanced queries
  static Future<void> exampleAdvancedQueries() async {
    if (!SupabaseConfig.isInitialized) return;

    final client = SupabaseConfig.client;
    if (client == null) {
      debugPrint('Supabase client not available');
      return;
    }

    try {
      // Get daily totals for the past week
      final weekAgo = DateTime.now().subtract(const Duration(days: 7));
      
      final weeklyData = await client
          .from('water_intakes')
          .select('glasses_count, intake_time::date as date')
          .eq('device_id', 'example-device-123')
          .gte('intake_time', weekAgo.toIso8601String())
          .order('intake_time');

      // Group by date (you'd normally do this with SQL aggregation)
      final dailyTotals = <String, double>{};
      for (final intake in weeklyData) {
        final date = intake['date'] as String;
        final glasses = (intake['glasses_count'] as num).toDouble();
        dailyTotals[date] = (dailyTotals[date] ?? 0) + glasses;
      }

      debugPrint('Weekly totals: $dailyTotals');

      // Get average daily intake
      final avgResult = await client
          .rpc('calculate_avg_daily_intake', params: {
            'device_id_param': 'example-device-123',
            'days_param': 7
          });

      debugPrint('Average daily intake: $avgResult');

    } catch (e) {
      debugPrint('Error in advanced queries: $e');
    }
  }

  // Example: Error handling patterns
  static Future<Map<String, dynamic>?> safeInsertWaterIntake(
    String deviceId, 
    double glassesCount
  ) async {
    try {
      if (!SupabaseConfig.isInitialized) {
        throw Exception('Supabase not initialized');
      }

      final client = SupabaseConfig.client;
      if (client == null) {
        throw Exception('Supabase client not available');
      }
      
      final result = await client
          .from('water_intakes')
          .insert({
            'device_id': deviceId,
            'glasses_count': glassesCount,
            'intake_time': DateTime.now().toIso8601String(),
          })
          .select()
          .single();

      return result;

    } on PostgrestException catch (e) {
      debugPrint('Database error: ${e.message}');
      debugPrint('Error code: ${e.code}');
      debugPrint('Error details: ${e.details}');
      return null;
      
    } catch (e) {
      debugPrint('General error: $e');
      return null;
    }
  }

  // Example: Batch operations
  static Future<bool> batchInsertWaterIntakes(
    String deviceId, 
    List<Map<String, dynamic>> intakes
  ) async {
    try {
      if (!SupabaseConfig.isInitialized) return false;

      // Add device_id to all intakes
      final dataWithDeviceId = intakes.map((intake) => {
        ...intake,
        'device_id': deviceId,
      }).toList();

      final client = SupabaseConfig.client;
      if (client == null) {
        throw Exception('Supabase client not available');
      }
      
      await client
          .from('water_intakes')
          .insert(dataWithDeviceId);

      debugPrint('Batch inserted ${intakes.length} water intakes');
      return true;

    } catch (e) {
      debugPrint('Error in batch insert: $e');
      return false;
    }
  }
}

// Example: Custom RPC functions you might create in Supabase
// These would be created in your Supabase SQL editor:
/*

-- Calculate average daily intake for a device
CREATE OR REPLACE FUNCTION calculate_avg_daily_intake(
  device_id_param TEXT,
  days_param INTEGER DEFAULT 7
)
RETURNS DECIMAL(5,2) AS $$
BEGIN
  RETURN (
    SELECT AVG(daily_total)::DECIMAL(5,2)
    FROM (
      SELECT 
        DATE(intake_time) as date,
        SUM(glasses_count) as daily_total
      FROM water_intakes
      WHERE device_id = device_id_param
        AND intake_time >= NOW() - INTERVAL '1 day' * days_param
      GROUP BY DATE(intake_time)
    ) daily_sums
  );
END;
$$ LANGUAGE plpgsql;

-- Get hydration streak (consecutive days meeting goal)
CREATE OR REPLACE FUNCTION get_hydration_streak(
  device_id_param TEXT,
  daily_goal_param INTEGER DEFAULT 8
)
RETURNS INTEGER AS $$
DECLARE
  streak_count INTEGER := 0;
  check_date DATE := CURRENT_DATE;
  daily_total DECIMAL(5,2);
BEGIN
  LOOP
    SELECT COALESCE(SUM(glasses_count), 0) INTO daily_total
    FROM water_intakes
    WHERE device_id = device_id_param
      AND DATE(intake_time) = check_date;
    
    IF daily_total >= daily_goal_param THEN
      streak_count := streak_count + 1;
      check_date := check_date - INTERVAL '1 day';
    ELSE
      EXIT;
    END IF;
  END LOOP;
  
  RETURN streak_count;
END;
$$ LANGUAGE plpgsql;

*/