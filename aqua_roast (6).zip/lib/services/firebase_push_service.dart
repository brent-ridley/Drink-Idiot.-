import 'dart:io';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class FirebasePushService {
  static bool _inited = false;

  static Future<void> init() async {
    if (_inited) return;

    // Configure Firebase (uses GoogleService-Info.plist on iOS automatically)
    await Firebase.initializeApp();

    // iOS permission prompt
    if (Platform.isIOS || Platform.isMacOS) {
      final settings = await FirebaseMessaging.instance.requestPermission(
        alert: true, badge: true, sound: true,
        provisional: false,
      );
      debugPrint('🔔 APNs permission: ${settings.authorizationStatus}');
    }

    // Get FCM token (this is what your server/DreamFlow/Supabase needs)
    final token = await FirebaseMessaging.instance.getToken();
    debugPrint('📬 FCM token: $token');

    // Listen for refreshes
    FirebaseMessaging.instance.onTokenRefresh.listen((t) {
      debugPrint('🔄 FCM token refreshed: $t');
    });

    // Foreground notification presentation options (iOS)
    await FirebaseMessaging.instance.setForegroundNotificationPresentationOptions(
      alert: true, badge: true, sound: true,
    );

    _inited = true;
  }

  static Future<String?> getToken() async {
    try {
      return await FirebaseMessaging.instance.getToken();
    } catch (e) {
      debugPrint('Error getting FCM token: $e');
      return null;
    }
  }

  static Future<bool> isInitialized() async {
    return _inited;
  }
}