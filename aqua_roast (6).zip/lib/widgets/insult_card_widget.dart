import 'package:flutter/material.dart';
import 'package:aqua_roast/services/insult_service.dart';
import 'package:aqua_roast/utils/hydration_colors.dart';

class InsultCardWidget extends StatelessWidget {
  final String insult;
  final int hydrationLevel;

  const InsultCardWidget({
    super.key,
    required this.insult,
    required this.hydrationLevel,
  });

  @override
  Widget build(BuildContext context) {
    final cardColor = _getCardColor(context, hydrationLevel);
    final textColor = _getTextColor(context, hydrationLevel);
    
    return Card(
      color: cardColor,
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  _getIcon(hydrationLevel),
                  color: textColor,
                  size: 28,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    _getTitle(hydrationLevel),
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      color: textColor,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Text(
              insult,
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                color: textColor,
                fontWeight: FontWeight.w500,
                height: 1.4,
              ),
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: textColor.withValues(alpha: 0.2),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Text(
                InsultService.getMotivationalMessage(hydrationLevel),
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: textColor,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Color _getCardColor(BuildContext context, int level) {
    return HydrationColors.getLightColor(level);
  }

  Color _getTextColor(BuildContext context, int level) {
    return HydrationColors.getDarkColor(level);
  }

  IconData _getIcon(int level) {
    switch (level) {
      case 0:
        return Icons.warning;
      case 1:
        return Icons.error_outline;
      case 2:
        return Icons.info_outline;
      case 3:
        return Icons.thumb_up_outlined;
      case 4:
        return Icons.star_outline;
      case 5:
        return Icons.emoji_events;
      default:
        return Icons.local_drink;
    }
  }

  String _getTitle(int level) {
    switch (level) {
      case 0:
        return 'CRITICAL ALERT!';
      case 1:
        return 'WARNING!';
      case 2:
        return 'NOTICE';
      case 3:
        return 'PROGRESS UPDATE';
      case 4:
        return 'WELL DONE!';
      case 5:
        return 'ACHIEVEMENT UNLOCKED!';
      default:
        return 'HYDRATION STATUS';
    }
  }
}

