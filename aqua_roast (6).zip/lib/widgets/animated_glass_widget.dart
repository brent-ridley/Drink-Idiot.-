import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:aqua_roast/models/water_intake.dart';
import 'package:aqua_roast/utils/hydration_colors.dart';

class AnimatedGlassWidget extends StatefulWidget {
  final DailyProgress progress;

  const AnimatedGlassWidget({super.key, required this.progress});

  @override
  State<AnimatedGlassWidget> createState() => _AnimatedGlassWidgetState();
}

class _AnimatedGlassWidgetState extends State<AnimatedGlassWidget>
    with TickerProviderStateMixin {
  late AnimationController _fillController;
  late AnimationController _waveController;
  late Animation<double> _fillAnimation;
  late Animation<double> _waveAnimation;
  double _previousProgress = 0.0;

  @override
  void initState() {
    super.initState();
    
    _fillController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );
    
    _waveController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    );

    _fillAnimation = Tween<double>(
      begin: 0.0,
      end: widget.progress.progressPercentage.clamp(0.0, 1.0),
    ).animate(CurvedAnimation(
      parent: _fillController,
      curve: Curves.easeInOutCubic,
    ));

    _waveAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _waveController,
      curve: Curves.linear,
    ));

    _waveController.repeat();
    _fillController.forward();
  }

  @override
  void didUpdateWidget(AnimatedGlassWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    
    final newProgress = widget.progress.progressPercentage.clamp(0.0, 1.0);
    if (newProgress != _previousProgress) {
      _fillAnimation = Tween<double>(
        begin: _previousProgress,
        end: newProgress,
      ).animate(CurvedAnimation(
        parent: _fillController,
        curve: Curves.easeInOutCubic,
      ));
      
      _fillController.reset();
      _fillController.forward();
      _previousProgress = newProgress;
    }
  }

  @override
  void dispose() {
    _fillController.dispose();
    _waveController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            Text(
              'Daily Progress',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: 200,
              height: 280,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  AnimatedBuilder(
                    animation: Listenable.merge([_fillAnimation, _waveAnimation]),
                    builder: (context, child) {
                      return CustomPaint(
                        size: const Size(200, 280),
                        painter: GlassPainter(
                          fillLevel: _fillAnimation.value,
                          waveOffset: _waveAnimation.value,
                          hydrationLevel: widget.progress.hydrationLevel,
                        ),
                      );
                    },
                  ),
                  // Percentage text inside the glass
                  Positioned(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          '${(widget.progress.progressPercentage * 100).round()}%',
                          style: Theme.of(context).textTheme.headlineLarge?.copyWith(
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                            shadows: [
                              Shadow(
                                blurRadius: 6.0,
                                color: Colors.black.withValues(alpha: 0.8),
                                offset: const Offset(2.0, 2.0),
                              ),
                              Shadow(
                                blurRadius: 3.0,
                                color: Colors.black.withValues(alpha: 0.6),
                                offset: const Offset(1.0, 1.0),
                              ),
                            ],
                          ),
                        ),
                        Text(
                          'Complete',
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                            shadows: [
                              Shadow(
                                blurRadius: 6.0,
                                color: Colors.black.withValues(alpha: 0.8),
                                offset: const Offset(2.0, 2.0),
                              ),
                              Shadow(
                                blurRadius: 3.0,
                                color: Colors.black.withValues(alpha: 0.6),
                                offset: const Offset(1.0, 1.0),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Column(
              children: [
                Text(
                  widget.progress.totalGlasses == widget.progress.totalGlasses.round() 
                    ? '${widget.progress.totalGlasses.round()}'
                    : widget.progress.totalGlasses.toStringAsFixed(1),
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: _getProgressColor(widget.progress.hydrationLevel),
                  ),
                ),
                Text(
                  'of ${widget.progress.dailyGoal} glasses',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            if (widget.progress.progressPercentage >= 1.0)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: _getProgressColor(widget.progress.hydrationLevel),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Text(
                  'GOAL ACHIEVED!',
                  style: Theme.of(context).textTheme.labelMedium?.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            const SizedBox(height: 8),
            Text(
              _getHydrationLevelText(widget.progress.hydrationLevel),
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: _getProgressColor(widget.progress.hydrationLevel),
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Color _getProgressColor(int level) {
    return HydrationColors.getPrimaryColor(level);
  }

  String _getHydrationLevelText(int level) {
    switch (level) {
      case 0:
        return 'CRITICALLY DEHYDRATED';
      case 1:
        return 'SEVERELY DEHYDRATED';
      case 2:
        return 'MODERATELY DEHYDRATED';
      case 3:
        return 'SLIGHTLY DEHYDRATED';
      case 4:
        return 'WELL HYDRATED';
      case 5:
        return 'PERFECTLY HYDRATED';
      default:
        return 'UNKNOWN STATUS';
    }
  }

  Color _getTextColorForProgress(double progress) {
    // Always use white text with shadow for visibility at all stages
    return Colors.white;
  }
}

class GlassPainter extends CustomPainter {
  final double fillLevel;
  final double waveOffset;
  final int hydrationLevel;

  GlassPainter({
    required this.fillLevel,
    required this.waveOffset,
    required this.hydrationLevel,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..style = PaintingStyle.fill;
    final strokePaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.0
      ..color = Colors.grey.shade400;

    final width = size.width;
    final height = size.height;

    // Draw glass outline (slightly tapered)
    final glassPath = Path();
    final topWidth = width * 0.8;
    final bottomWidth = width * 0.6;
    final glassHeight = height * 0.85;
    final startY = height * 0.1;

    glassPath.moveTo((width - topWidth) / 2, startY);
    glassPath.lineTo((width + topWidth) / 2, startY);
    glassPath.lineTo((width + bottomWidth) / 2, startY + glassHeight);
    glassPath.lineTo((width - bottomWidth) / 2, startY + glassHeight);
    glassPath.close();

    // Calculate water fill level
    final waterHeight = glassHeight * fillLevel;
    final waterTop = startY + glassHeight - waterHeight;

    if (fillLevel > 0) {
      // Create water path with waves
      final waterPath = Path();
      final waveHeight = 8.0;
      final waveFrequency = 2.0;

      // Calculate water width at current level (linear interpolation)
      final waterWidthTop = bottomWidth + (topWidth - bottomWidth) * (waterHeight / glassHeight);
      final waterWidthBottom = bottomWidth;

      // Draw wavy top of water
      waterPath.moveTo((width - waterWidthTop) / 2, waterTop);
      
      for (double x = (width - waterWidthTop) / 2; x <= (width + waterWidthTop) / 2; x += 2) {
        final normalizedX = (x - (width - waterWidthTop) / 2) / waterWidthTop;
        final wave = waveHeight * 0.3 * 
          (fillLevel < 1.0 ? 1.0 : 0.5) * // Reduce wave when full
          math.sin((normalizedX * waveFrequency + waveOffset) * 2 * math.pi);
        waterPath.lineTo(x, waterTop + wave);
      }

      // Complete the water shape
      waterPath.lineTo((width + waterWidthBottom) / 2, startY + glassHeight);
      waterPath.lineTo((width - waterWidthBottom) / 2, startY + glassHeight);
      waterPath.close();

      // Set water color based on hydration level
      paint.color = _getWaterColor(hydrationLevel).withValues(alpha: 0.8);
      canvas.drawPath(waterPath, paint);

      // Add water shine effect
      final shinePaint = Paint()
        ..color = Colors.white.withValues(alpha: 0.3)
        ..style = PaintingStyle.fill;
      
      final shinePath = Path();
      shinePath.moveTo((width - waterWidthTop) / 2 + 10, waterTop + 5);
      shinePath.lineTo((width - waterWidthTop) / 2 + 30, waterTop + 5);
      shinePath.lineTo((width - waterWidthBottom) / 2 + 25, startY + glassHeight - 10);
      shinePath.lineTo((width - waterWidthBottom) / 2 + 15, startY + glassHeight - 10);
      shinePath.close();
      
      canvas.drawPath(shinePath, shinePaint);
    }

    // Draw glass outline
    canvas.drawPath(glassPath, strokePaint);

    // Add glass shine
    final glassShinePaint = Paint()
      ..color = Colors.white.withValues(alpha: 0.2)
      ..style = PaintingStyle.fill;
    
    final glassShinePath = Path();
    glassShinePath.moveTo((width - topWidth) / 2 + 5, startY + 5);
    glassShinePath.lineTo((width - topWidth) / 2 + 25, startY + 5);
    glassShinePath.lineTo((width - bottomWidth) / 2 + 20, startY + glassHeight - 5);
    glassShinePath.lineTo((width - bottomWidth) / 2 + 10, startY + glassHeight - 5);
    glassShinePath.close();
    
    canvas.drawPath(glassShinePath, glassShinePaint);
  }

  Color _getWaterColor(int level) {
    return HydrationColors.getWaterColor(level);
  }

  @override
  bool shouldRepaint(covariant GlassPainter oldDelegate) {
    return fillLevel != oldDelegate.fillLevel ||
           waveOffset != oldDelegate.waveOffset ||
           hydrationLevel != oldDelegate.hydrationLevel;
  }
}