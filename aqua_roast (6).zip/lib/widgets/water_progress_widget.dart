import 'package:flutter/material.dart';
import 'package:aqua_roast/models/water_intake.dart';
import 'package:aqua_roast/utils/app_colors.dart';

class WaterProgressWidget extends StatelessWidget {
  final DailyProgress progress;

  const WaterProgressWidget({super.key, required this.progress});

  @override
  Widget build(BuildContext context) {
    final progressPercentage = progress.progressPercentage;
    final isComplete = progressPercentage >= 1.0;
    
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            Text(
              'Daily Progress',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            Stack(
              alignment: Alignment.center,
              children: [
                SizedBox(
                  width: 150,
                  height: 150,
                  child: CircularProgressIndicator(
                    value: progressPercentage,
                    strokeWidth: 12,
                    backgroundColor: Theme.of(context).colorScheme.primary.withValues(alpha: 0.2),
                    valueColor: AlwaysStoppedAnimation<Color>(
                      _getProgressColor(context, progress.hydrationLevel),
                    ),
                  ),
                ),
                Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      progress.totalGlasses == progress.totalGlasses.round() 
                        ? '${progress.totalGlasses.round()}'
                        : progress.totalGlasses.toStringAsFixed(1),
                      style: Theme.of(context).textTheme.displaySmall?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: _getProgressColor(context, progress.hydrationLevel),
                      ),
                    ),
                    Text(
                      'of ${progress.dailyGoal}',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
                      ),
                    ),
                    Text(
                      'glasses',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 16),
            LinearProgressIndicator(
              value: progressPercentage,
              backgroundColor: Theme.of(context).colorScheme.primary.withValues(alpha: 0.2),
              valueColor: AlwaysStoppedAnimation<Color>(
                _getProgressColor(context, progress.hydrationLevel),
              ),
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '${(progressPercentage * 100).round()}% Complete',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                if (isComplete)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: _getProgressColor(context, progress.hydrationLevel),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      'GOAL ACHIEVED!',
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              _getHydrationLevelText(progress.hydrationLevel),
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: _getProgressColor(context, progress.hydrationLevel),
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Color _getProgressColor(BuildContext context, int level) {
    switch (level) {
      case 0:
        return Colors.red.shade600;
      case 1:
        return Colors.orange.shade600;
      case 2:
        return Colors.amber.shade600;
      case 3:
        return Colors.blue.shade600;
      case 4:
        return Colors.green.shade600;
      case 5:
        return AppColors.emerald.shade600;
      default:
        return Theme.of(context).colorScheme.primary;
    }
  }

  String _getHydrationLevelText(int level) {
    switch (level) {
      case 0:
        return 'CRITICALLY DEHYDRATED';
      case 1:
        return 'SEVERELY DEHYDRATED';
      case 2:
        return 'MODERATELY DEHYDRATED';
      case 3:
        return 'SLIGHTLY DEHYDRATED';
      case 4:
        return 'WELL HYDRATED';
      case 5:
        return 'PERFECTLY HYDRATED';
      default:
        return 'UNKNOWN STATUS';
    }
  }
}

