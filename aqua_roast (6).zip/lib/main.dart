import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:aqua_roast/theme.dart';
import 'package:aqua_roast/screens/home_screen.dart';
import 'package:aqua_roast/services/storage_service.dart';
import 'package:aqua_roast/services/notification_service.dart';
import 'package:aqua_roast/services/revenue_cat_service.dart';
import 'package:aqua_roast/services/firebase_push_service.dart';
import 'package:aqua_roast/supabase/supabase_config.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  try {
    // Initialize Firebase first
    await Firebase.initializeApp();
    await FirebasePushService.init();
    
    // Initialize Supabase
    try {
      await SupabaseConfig.initialize();
      debugPrint('Supabase client initialized successfully');
    } catch (e) {
      debugPrint('Supabase initialization error: $e');
    }
    
    // Initialize services
    await StorageService.init();
    
    // Initialize local notification service as fallback
    try {
      await NotificationService.init();
      await NotificationService.requestPermissions();
      // Schedule local notifications as backup
      await NotificationService.scheduleWaterReminders();
    } catch (e) {
      debugPrint('Local notification service error: $e');
    }
    
    // Initialize RevenueCat with error handling
    try {
      await RevenueCatService.initialize();
    } catch (e) {
      debugPrint('RevenueCat initialization error: $e');
    }
  } catch (e) {
    // If services fail to initialize, continue with basic functionality
    debugPrint('Service initialization error: $e');
  }
  
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Drink, Idiot',
      debugShowCheckedModeBanner: false,
      theme: lightTheme,
      darkTheme: darkTheme,
      themeMode: ThemeMode.system,
      home: const HomeScreen(),
    );
  }
}