import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:aqua_roast/services/storage_service.dart';
import 'package:aqua_roast/services/notification_service.dart';
import 'package:aqua_roast/services/revenue_cat_service.dart';
import 'package:aqua_roast/services/firebase_push_service.dart';
import 'package:aqua_roast/screens/subscription_screen.dart';
import 'package:aqua_roast/utils/hydration_colors.dart';
import 'package:aqua_roast/models/water_intake.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  int _dailyGoal = 8;
  int _notificationInterval = 60;
  DailyProgress? _progress;
  bool _isLoading = true;
  bool _isPremium = false;
  bool _notificationsEnabled = false;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final goal = await StorageService.getDailyGoal();
    final interval = await StorageService.getNotificationInterval();
    final progress = await StorageService.getTodaysProgress();
    final isPremium = await RevenueCatService.isPremium();
    final notificationsEnabled = await NotificationService.areNotificationsEnabled();
    
    setState(() {
      _dailyGoal = goal;
      _notificationInterval = interval;
      _progress = progress;
      _isPremium = isPremium;
      _notificationsEnabled = notificationsEnabled;
      _isLoading = false;
    });
  }

  Future<void> _showSubscriptionScreen() async {
    final result = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (context) => const SubscriptionScreen(),
        fullscreenDialog: true,
      ),
    );
    
    if (result == true) {
      // User purchased premium, refresh status
      _loadSettings();
    }
  }

  Future<void> _saveDailyGoal(int goal) async {
    await StorageService.setDailyGoal(goal);
    setState(() {
      _dailyGoal = goal;
    });
    
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Daily goal updated to $goal glasses!'),
          duration: const Duration(seconds: 2),
        ),
      );
    }
  }

  Future<void> _saveNotificationInterval(int intervalMinutes) async {
    await StorageService.setNotificationInterval(intervalMinutes);
    
    // Reschedule notifications with new interval
    await NotificationService.scheduleWaterReminders();
    
    // Note: Firebase push notifications are handled by the backend
    // Local notifications are already rescheduled above
    
    setState(() {
      _notificationInterval = intervalMinutes;
    });
    
    String intervalText;
    if (intervalMinutes == 15) {
      intervalText = '15 minutes';
    } else if (intervalMinutes == 30) {
      intervalText = '30 minutes';
    } else if (intervalMinutes == 60) {
      intervalText = '1 hour';
    } else if (intervalMinutes == 120) {
      intervalText = '2 hours';
    } else {
      intervalText = '$intervalMinutes minutes';
    }
    
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Notification interval updated to $intervalText!'),
          duration: const Duration(seconds: 2),
        ),
      );
    }
  }

  Future<void> _showResetDialog() async {
    final result = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Reset All Data'),
          content: const Text(
            'Are you sure you want to reset all your water intake data? '
            'This action cannot be undone.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(context).pop(true),
              style: FilledButton.styleFrom(
                backgroundColor: Theme.of(context).colorScheme.error,
              ),
              child: const Text('Reset'),
            ),
          ],
        );
      },
    );

    if (result == true && mounted) {
      await StorageService.clearAllData();
      await StorageService.init();
      Navigator.of(context).pop(); // Go back to home screen
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('All data has been reset!'),
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'SETTINGS',
          style: Theme.of(context).textTheme.headlineMedium?.copyWith(
            color: _progress != null
                ? HydrationColors.getOnPrimaryColor(_progress!.hydrationLevel)
                : Theme.of(context).colorScheme.onPrimary,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
        backgroundColor: _progress != null
            ? HydrationColors.getPrimaryColor(_progress!.hydrationLevel)
            : Theme.of(context).colorScheme.primary,
        iconTheme: IconThemeData(
          color: _progress != null
              ? HydrationColors.getOnPrimaryColor(_progress!.hydrationLevel)
              : Theme.of(context).colorScheme.onPrimary,
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Daily Water Goal',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Set your daily water intake goal (glasses)',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        IconButton(
                          onPressed: _dailyGoal > 1
                              ? () => _saveDailyGoal(_dailyGoal - 1)
                              : null,
                          icon: const Icon(Icons.remove_circle),
                          iconSize: 32,
                        ),
                        const SizedBox(width: 16),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 24,
                            vertical: 12,
                          ),
                          decoration: BoxDecoration(
                            color: Theme.of(context).colorScheme.primaryContainer,
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Text(
                            '$_dailyGoal',
                            style: Theme.of(context).textTheme.displaySmall?.copyWith(
                              color: Theme.of(context).colorScheme.onPrimaryContainer,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        const SizedBox(width: 16),
                        IconButton(
                          onPressed: _dailyGoal < 20
                              ? () => _saveDailyGoal(_dailyGoal + 1)
                              : null,
                          icon: const Icon(Icons.add_circle),
                          iconSize: 32,
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        for (int preset in [6, 8, 10, 12])
                          TextButton(
                            onPressed: _dailyGoal != preset
                                ? () => _saveDailyGoal(preset)
                                : null,
                            child: Text('$preset'),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Notification Reminders',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'How often should we insult you to drink water?',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
                      ),
                    ),
                    const SizedBox(height: 12),
                    // Centered notification status indicator
                    Center(
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                        decoration: BoxDecoration(
                          color: _notificationsEnabled 
                              ? Theme.of(context).colorScheme.primaryContainer.withValues(alpha: 0.3)
                              : Theme.of(context).colorScheme.errorContainer.withValues(alpha: 0.3),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: _notificationsEnabled 
                                ? Theme.of(context).colorScheme.primary.withValues(alpha: 0.5)
                                : Theme.of(context).colorScheme.error.withValues(alpha: 0.5),
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              _notificationsEnabled ? Icons.notifications_active : Icons.notifications_off,
                              size: 18,
                              color: _notificationsEnabled 
                                  ? Theme.of(context).colorScheme.primary
                                  : Theme.of(context).colorScheme.error,
                            ),
                            const SizedBox(width: 8),
                            Text(
                              _notificationsEnabled ? 'Notifications Enabled' : 'Notifications Disabled',
                              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                color: _notificationsEnabled 
                                    ? Theme.of(context).colorScheme.primary
                                    : Theme.of(context).colorScheme.error,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        for (final interval in [
                          {'minutes': 15, 'label': '15 min'},
                          {'minutes': 30, 'label': '30 min'},
                          {'minutes': 60, 'label': '1 hour'},
                          {'minutes': 120, 'label': '2 hours'},
                        ])
                          FilterChip(
                            label: Text(interval['label'] as String),
                            selected: _notificationInterval == (interval['minutes'] as int),
                            onSelected: (selected) {
                              if (selected) {
                                _saveNotificationInterval(interval['minutes'] as int);
                              }
                            },
                            backgroundColor: Theme.of(context).colorScheme.surface,
                            selectedColor: Theme.of(context).colorScheme.primaryContainer,
                            labelStyle: TextStyle(
                              color: _notificationInterval == (interval['minutes'] as int)
                                  ? Theme.of(context).colorScheme.onPrimaryContainer
                                  : Theme.of(context).colorScheme.onSurface,
                              fontWeight: _notificationInterval == (interval['minutes'] as int)
                                  ? FontWeight.bold
                                  : FontWeight.normal,
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Center(
                      child: SizedBox(
                        width: 200,
                        child: FilledButton.icon(
                          onPressed: () async {
                            // Show loading indicator
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('Testing push notifications...'),
                                duration: Duration(seconds: 1),
                              ),
                            );
                            
                            // Test local notification instead
                            await NotificationService.showImmediateInsult();
                            
                            // Update notification status after test
                            final notificationsEnabled = await NotificationService.areNotificationsEnabled();
                            
                            if (mounted) {
                              // Update UI state
                              setState(() {
                                _notificationsEnabled = notificationsEnabled;
                              });
                              
                              // Hide loading message
                              ScaffoldMessenger.of(context).hideCurrentSnackBar();
                              
                              // Show result
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: const Text('Test notification sent! Check your notification panel.'),
                                  backgroundColor: Theme.of(context).colorScheme.primary,
                                  duration: const Duration(seconds: 3),
                                ),
                              );
                            }
                          },
                          icon: const Icon(Icons.notification_add),
                          label: const Text('Test Notification'),
                          style: FilledButton.styleFrom(
                            backgroundColor: Theme.of(context).colorScheme.primary,
                            padding: const EdgeInsets.symmetric(
                              horizontal: 20,
                              vertical: 14,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            // FCM Token Display Card
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Firebase Push Notifications',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'FCM Token for external testing (tap to copy)',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
                      ),
                    ),
                    const SizedBox(height: 12),
                    FutureBuilder<String?>(
                      future: FirebasePushService.getToken(),
                      builder: (context, snapshot) {
                        if (snapshot.connectionState == ConnectionState.waiting) {
                          return const Row(
                            children: [
                              SizedBox(
                                width: 16,
                                height: 16,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              ),
                              SizedBox(width: 8),
                              Text('Loading FCM Token...'),
                            ],
                          );
                        }
                        
                        final token = snapshot.data;
                        if (token == null || token.isEmpty) {
                          return Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Theme.of(context).colorScheme.errorContainer.withValues(alpha: 0.3),
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                color: Theme.of(context).colorScheme.error.withValues(alpha: 0.5),
                              ),
                            ),
                            child: Row(
                              children: [
                                Icon(
                                  Icons.error_outline,
                                  size: 16,
                                  color: Theme.of(context).colorScheme.error,
                                ),
                                const SizedBox(width: 6),
                                Expanded(
                                  child: Text(
                                    'Firebase not initialized or FCM token unavailable',
                                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                      color: Theme.of(context).colorScheme.error,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        }
                        
                        return GestureDetector(
                          onTap: () {
                            Clipboard.setData(ClipboardData(text: token));
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('FCM Token copied to clipboard!'),
                                duration: Duration(seconds: 2),
                              ),
                            );
                          },
                          child: Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Theme.of(context).colorScheme.surfaceVariant,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                color: Theme.of(context).colorScheme.outline.withValues(alpha: 0.3),
                              ),
                            ),
                            child: Row(
                              children: [
                                Icon(
                                  Icons.content_copy,
                                  size: 16,
                                  color: Theme.of(context).colorScheme.primary,
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    token.length > 30 ? '${token.substring(0, 30)}...' : token,
                                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                      fontFamily: 'monospace',
                                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                                    ),
                                  ),
                                ),
                                Icon(
                                  Icons.tap_and_play,
                                  size: 16,
                                  color: Theme.of(context).colorScheme.primary,
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Use this FCM token with Firebase Console or your backend to send targeted push notifications.',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.6),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            // Premium/Subscription Card
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _isPremium ? 'Premium Status' : 'Upgrade to Premium',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 12),
                    if (_isPremium) ...[
                      Row(
                        children: [
                          Icon(
                            Icons.check_circle,
                            color: Theme.of(context).colorScheme.primary,
                            size: 20,
                          ),
                          const SizedBox(width: 8),
                          Text(
                            'You have premium access!',
                            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color: Theme.of(context).colorScheme.primary,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Enjoy unlimited water tracking and premium insults!',
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.8),
                        ),
                      ),
                    ] else ...[
                      FutureBuilder<String>(
                        future: RevenueCatService.getRemainingTrialDays(),
                        builder: (context, snapshot) {
                          final trialStatus = snapshot.data ?? 'Loading...';
                          final isTrialExpired = trialStatus == 'Trial Expired';
                          
                          return Column(
                            children: [
                              if (!isTrialExpired) ...[
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                  decoration: BoxDecoration(
                                    color: Theme.of(context).colorScheme.primaryContainer.withValues(alpha: 0.3),
                                    borderRadius: BorderRadius.circular(20),
                                    border: Border.all(
                                      color: Theme.of(context).colorScheme.primary.withValues(alpha: 0.5),
                                    ),
                                  ),
                                  child: Text(
                                    '🎉 Free Trial: $trialStatus',
                                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                      color: Theme.of(context).colorScheme.primary,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 12),
                              ],
                              Text(
                                isTrialExpired 
                                    ? 'Your free trial has ended. Continue with unlimited water tracking and premium features!'
                                    : 'Enjoy your free trial! Upgrade anytime for unlimited water tracking and continued support.',
                                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                  color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.8),
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ],
                          );
                        },
                      ),
                      const SizedBox(height: 16),
                      Center(
                        child: FilledButton.icon(
                          onPressed: () async {
                            try {
                              // Show loading indicator
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('Loading payment options...'),
                                  duration: Duration(seconds: 2),
                                ),
                              );
                              
                              // Navigate to subscription screen instead of direct purchase
                              final result = await Navigator.of(context).push<bool>(
                                MaterialPageRoute(
                                  builder: (context) => const SubscriptionScreen(),
                                  fullscreenDialog: true,
                                ),
                              );
                              
                              if (mounted) {
                                // Hide loading message
                                ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                
                                if (result == true) {
                                  // Purchase successful, refresh premium status
                                  _loadSettings();
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: const Text('Welcome to Premium!'),
                                      backgroundColor: Theme.of(context).colorScheme.primary,
                                      duration: const Duration(seconds: 3),
                                    ),
                                  );
                                }
                              }
                            } catch (e) {
                              if (mounted) {
                                ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text('Error: ${e.toString()}'),
                                    backgroundColor: Theme.of(context).colorScheme.error,
                                    duration: const Duration(seconds: 3),
                                  ),
                                );
                              }
                            }
                          },
                          icon: const Icon(Icons.star),
                          label: const Text('Upgrade Now'),
                          style: FilledButton.styleFrom(
                            backgroundColor: Theme.of(context).colorScheme.primary,
                            padding: const EdgeInsets.symmetric(
                              horizontal: 24,
                              vertical: 12,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'About',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Drink, Idiot is a water reminder app that uses insults to motivate you to stay hydrated. The meaner the insult, the more dehydrated you are!',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                    const SizedBox(height: 12),
                    Text(
                      '• Each glass represents ~8oz (240ml) of water\n'
                      '• Your insults get nicer as you drink more\n'
                      '• Progress resets daily at midnight\n'
                      '• Stay hydrated, you beautiful human!',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.8),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
            OutlinedButton.icon(
              onPressed: _showResetDialog,
              icon: const Icon(Icons.delete_forever),
              label: const Text('Reset All Data'),
              style: OutlinedButton.styleFrom(
                foregroundColor: Theme.of(context).colorScheme.error,
                side: BorderSide(
                  color: Theme.of(context).colorScheme.error,
                ),
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
            ),
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }
}