-- Database schema for Drink, Idiot water reminder app
-- Note: This SQL is designed to be run in Supabase

-- Notification tokens table to track device registrations
CREATE TABLE IF NOT EXISTS notification_tokens (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id TEXT UNIQUE NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  is_active BOOLEAN DEFAULT true
);

-- Notifications table to store sent notifications
CREATE TABLE IF NOT EXISTS notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id TEXT NOT NULL,
  title TEXT NOT NULL DEFAULT 'Drink, Idiot!',
  body TEXT NOT NULL,
  sent_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  delivered BOOLEAN DEFAULT false,
  delivered_at TIMESTAMP WITH TIME ZONE,
  notification_type TEXT DEFAULT 'water_reminder',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Notification schedules to track device preferences
CREATE TABLE IF NOT EXISTS notification_schedules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id TEXT UNIQUE NOT NULL,
  interval_minutes INTEGER NOT NULL DEFAULT 60,
  active BOOLEAN DEFAULT true,
  start_hour INTEGER DEFAULT 8,
  end_hour INTEGER DEFAULT 22,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Water intake tracking (optional - for future analytics)
CREATE TABLE IF NOT EXISTS water_intakes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id TEXT NOT NULL,
  glasses_count DECIMAL(5,2) NOT NULL DEFAULT 0.0,
  intake_time TIMESTAMP WITH TIME ZONE DEFAULT now(),
  daily_goal INTEGER DEFAULT 8,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Indexes for better performance
CREATE INDEX IF NOT EXISTS idx_notification_tokens_device_id ON notification_tokens(device_id);
CREATE INDEX IF NOT EXISTS idx_notifications_device_id ON notifications(device_id);
CREATE INDEX IF NOT EXISTS idx_notifications_delivered ON notifications(delivered, sent_at);
CREATE INDEX IF NOT EXISTS idx_notification_schedules_device_id ON notification_schedules(device_id);
CREATE INDEX IF NOT EXISTS idx_water_intakes_device_id ON water_intakes(device_id);
-- Index for device and time queries (simpler approach to avoid immutable function issues)
CREATE INDEX IF NOT EXISTS idx_water_intakes_device_time ON water_intakes(device_id, intake_time);

-- Note: This schema follows Supabase best practices
-- Automatic timestamp updates can be handled at the application level
-- or through Supabase's built-in functionality